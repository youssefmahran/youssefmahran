package engine;

import java.util.ArrayList;

import model.world.Champion;

public class Player {
	private String name;
	private ArrayList<Champion> team;
	private Champion leader;
	

	public Player(String name) {
		this.name = name;
		team = new ArrayList<Champion>();
		
	}


	public Champion getLeader() {
		return leader;
	}

	public Champion getHighestSpeed() {
		Champion c = team.get(0);
		for(int i = 1; i < team.size(); i++)
			if(team.get(i).getSpeed() > c.getSpeed())
				c = team.get(i);
		return c;
	}
	
	public void setLeader(Champion leader) {
		this.leader = leader;
	}

	public String getName() {
		return name;
	}

	public ArrayList<Champion> getTeam() {
		return team;
	}

	public int getIndex(Champion c) {
		for(int i = 0; i < team.size(); i++)
			if(c.getName().equals(team.get(i).getName()))
				return i;
		return 0;
	}

}
