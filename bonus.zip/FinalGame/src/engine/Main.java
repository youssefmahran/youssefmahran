package engine;

import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import controls.*;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.abilities.*;
import model.effects.Effect;
import model.effects.EffectType;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;

public class Main extends Application{
	private Clip MenuClip;
	private Stage stage;
	private Scene Scene;
	private final double widthh = Screen.getPrimary().getBounds().getWidth();
	private final double heightt = Screen.getPrimary().getBounds().getHeight();
	private Player p1;
	private Player p2;
	private Game game;
	private boolean first;
	private boolean second;
	private boolean third;
	private boolean fourth;
	private boolean fifth;
	private boolean sixth;
	private boolean seventh;
	private boolean isMainMenu;
	private boolean isSelectNames;
	private boolean isSelectChampion;
	private boolean isExit;
	private boolean isSelectLeader;
	private boolean isInstructionsPane;
	private boolean isGamePane;
	private boolean isSettings;
	private CheckBox1 On;
	private CheckBox1 Off;
	private AnchorPane1 MainMenu;
	private Label1 ToggleMusic;
	private Button1 ExitGame;
	private Button1 instructions;
	private Button1 SinglePlayer;
	private Button1 MultiPlayer;
	private ImageView1 Logo;
	private Label1 on;
	private Label1 off;
	private AnchorPane1 InstructionsPane;
	private AnchorPane1 SelectChampions;
	private AnchorPane1 SelectNames;
	private AnchorPane1 SelectLeader;
	private AnchorPane1 GamePane;
	private TextField1 Player1;
	private TextField1 Player2;
	private Label1 ChooseName;
	private Label1 Pl1;
	private Label1 Pl2;
	private Button1 Back;
	private Button1 Next;
	private int togglesNo = 0;
	private int whichChampion = 1;
	private Label1 choose;
	private BorderGlow borderGlow;
	private RedBorderGlow redBorderGlow;
	private BlueBorderGlow blueBorderGlow;
	private BlackBorderGlow blackBorderGlow;
	private CaptainAmerica captainAmerica;
	private DeadPool deadPool;     
	private DoctorStrange doctorStrange;
	private Electro electro;    
	private GhostRider ghostRider;   
	private Hela hela;   
	private Hulk hulk;
	private Iceman iceman;
	private Ironman ironman;
	private Loki loki;
	private QuickSilver quickSilver;
	private Spiderman spiderman;
	private Thor thor;
	private Venom venom;
	private YellowJacket yellowJacket;
	private Next next;
	private model.world.Direction d;
	private ArrayList<ToggleButton> champions;
	private ArrayList<Champion> playersChampions = new ArrayList<Champion>();
	private ArrayList<LeaderButton> players1 = new ArrayList<LeaderButton>();
	private ArrayList<LeaderButton> players2 = new ArrayList<LeaderButton>();
	private Player1 player1;
	private Player2 player2;
	private GridPane1 grid;
	private int action;
	private Button1 Move;
	private Button1 Settings; 
	private boolean isFirstPlayer;
	private boolean isSecondPlayer;
	private GameOver gameOver;
	private Button1 Cast;
	private Button1 Attack;
	private Button1 Punch;
	private boolean firstAbility = false;
	private boolean secondAbility = false;
	private boolean thirdAbility = false;
	private boolean fourthAbility = false;
	private boolean punchAbility = false;
	private boolean punchPressed = false;
	private boolean isSinglePlayer;
	private Label1 Hover;
	private SettingsPane settingsPane;
	private TurnOrderPane turnOrder;
	private Button1 EndTurn;
	private int timer;
	
	@Override
	public void start(Stage primaryStage){
		try {
		primaryStage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
		final File f = new File("Intro.mp4");
	    
	    final Media m = new Media(f.toURI().toString());
	    final MediaPlayer mp = new MediaPlayer(m);
	    final MediaView mv = new MediaView(mp);
	    
	    final DoubleProperty width = mv.fitWidthProperty();
	    final DoubleProperty height = mv.fitHeightProperty();
	    
	    width.bind(Bindings.selectDouble(mv.sceneProperty(), "width"));
	    height.bind(Bindings.selectDouble(mv.sceneProperty(), "height"));
	    
	    mv.setPreserveRatio(true);
	    
	    
	    StackPane root = new StackPane();
	    root.getChildren().add(mv);
	    Scene = new Scene(root, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
	    Scene.setFill(Color.BLACK);
	    primaryStage.setScene(Scene);
	    primaryStage.setFullScreen(true);
	    primaryStage.getIcons().add(new Image("/images/marvel.png"));
		primaryStage.setTitle("Marvel's Avengers: Ultimate War");
	    primaryStage.show();
	    
	    mp.play();
	    mp.setOnEndOfMedia(new Runnable() {
	        public void run() {
				stage = primaryStage;
				switchToMainMenu();
	       }
	    });
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	public boolean checkTargetsUp(Champion c, Ability a) {
		Object[][] board = game.getBoard();
			int x = c.getLocation().x;
			int y = c.getLocation().y;
			for(int i = 0; i < a.getCastRange(); i++) {
				x++;
				if(x == 5)
					break;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
				   (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF)) 
					&& ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
					return true;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
						   (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF)) 
							&& ((p1.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) )) 
							return true;
					
			}
		return false;
	}
	
	public boolean checkTargetsDown(Champion c, Ability a) {
		Object[][] board = game.getBoard();
			int x = c.getLocation().x;
			int y = c.getLocation().y;
			for(int i = 0; i < a.getCastRange(); i++) {
				x--;
				if(x == -1)
					break;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
				   (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF)) 
					&& ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
					return true;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
						   (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF)) 
							&& ((p1.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) )) 
							return true;
					
			}
		return false;
	}
	
	public boolean checkTargetsRight(Champion c, Ability a) {
		Object[][] board = game.getBoard();
			int x = c.getLocation().x;
			int y = c.getLocation().y;
			for(int i = 0; i < a.getCastRange(); i++) {
				y++;
				if(y == 5)
					break;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
				   (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF)) 
					&& ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
					return true;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
						   (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF)) 
							&& ((p1.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) )) 
							return true;
					
			}
		return false;
	}
	
	public void updateGame() {
		player1.Update(p1.getTeam().get(0), p1);
		player2.Update(game.getCurrentChampion(), p2);
		player1.updateDead();
		player2.updateDead();
		game.UpdateGrid(grid.Grid, Hover, grid.health);
	}
	
	public boolean checkTargetsLeft(Champion c, Ability a) {
		Object[][] board = game.getBoard();
			int x = c.getLocation().x;
			int y = c.getLocation().y;
			for(int i = 0; i < a.getCastRange(); i++) {
				y--;
				if(y == -1)
					break;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
				   (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF)) 
					&& ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
					return true;
				if(board[x][y] != null && board[x][y] instanceof Champion && 
						   (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF)) 
							&& ((p1.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) )) 
							return true;
					
			}
		return false;
	}
	
	public boolean checkTargetsSurround(Champion c, Ability a) {
		boolean flag = false;
		Object[][] board = game.getBoard();
		Point Location = c.getLocation(), p = new Point(0,0);
		int x = Location.x - 1;
		int y = Location.y - 1;
		int t = 0;
		for(int i = 0; i < 3; i++) {
			if(x >=0 && x < 5) {
				y = Location.y - 1;
				for(int j = 0; j < 3; j++) {
					if(y >= 0 && y < 5) {
						p.x = x;
						p.y = y;
						if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
							t++;
							++y;
							continue;
						}
						if(board[x][y] != null && !p.equals(Location)){
							if(board[x][y] instanceof Champion && ((a instanceof HealingAbility && ((Champion) board[i][j]).getCurrentHP() < ((Champion) board[i][j]).getMaxHP()) || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF))) {
								Champion c2 = (Champion) board[x][y];
								if((p1.getTeam().contains(game.getCurrentChampion()) && p1.getTeam().contains(c2)))
									t++;
							}
							else {
								if(board[x][y] instanceof Champion && (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF))) {
									Champion c2 = (Champion) board[x][y];
									if(((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion())))) {
										t++;
										flag = true;
									}
								}
							}
						}
					}
					++y;
				}
			}
			++x;
		}
		if(t >= 2 && flag)
			return true;
		return false;
	}

	public boolean checkTargetsTeam(Champion c, Ability a) {
		ArrayList<Champion> team = null;
		int t = 0;
		if (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF)) {
			if (p1.getTeam().contains(game.getCurrentChampion()))
				team = p2.getTeam();
			else
				team = p1.getTeam();
			} 
		else 
			if (a instanceof HealingAbility || (a instanceof CrowdControlAbility && (a instanceof CrowdControlAbility && ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF))) {
				if (p1.getTeam().contains(game.getCurrentChampion()))
					team = p1.getTeam();
				else
					team = p2.getTeam();
			}
		for (Champion c1 : team) {
			int x = (int) c1.getLocation().getX();
			int y = (int) c1.getLocation().getY();
			int distance = Math.abs((int) game.getCurrentChampion().getLocation().getX() - x) + Math.abs((int) game.getCurrentChampion().getLocation().getY() - y);
			if(a instanceof HealingAbility && c1.getCurrentHP() >= c1.getMaxHP())
				continue;
			if (distance <= a.getCastRange()) 
				t++;
		}
		if(t == 2)
			return true;
		return false;
	}
	
	public Champion getTargetSingle(Champion c, Ability a) {
		Object[][] board = game.getBoard();
		int x = game.getCurrentChampion().getLocation().x;
		int y = game.getCurrentChampion().getLocation().y;
		for(int i = 0; i < 5; i++) {
			for(int j = 0; j < 5; j++) {
				if(board[i][j] != null && board[i][j] instanceof Cover && a instanceof DamagingAbility && distance(x, y, i, j) <= a.getCastRange()) {
					continue;
				}
				if(board[i][j] instanceof Champion && ((a instanceof HealingAbility && ((Champion) board[i][j]).getCurrentHP() < ((Champion) board[i][j]).getMaxHP()) || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF))) {
					Champion c2 = (Champion) board[i][j];
					if((p1.getTeam().contains(game.getCurrentChampion()) && p1.getTeam().contains(c2)) && distance(i, j, x, y) <= a.getCastRange()) 
						return c2;
				}
				else {
					if(board[i][j] instanceof Champion && (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF))) {
						Champion c2 = (Champion) board[i][j];
						if(((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion()))) && distance(i, j, x, y) <= a.getCastRange()) 
							return c2;
					}
				}
			}
		}
		return null;
	}
	
	public boolean validateAbility(Champion c, Ability a) {
		if(a instanceof HealingAbility && a.getCastArea() == AreaOfEffect.SELFTARGET && c.getCurrentHP() >= c.getMaxHP())
			return false;
		if(a.getCastArea() == AreaOfEffect.DIRECTIONAL)
			return checkTargetsUp(c,a) || checkTargetsDown(c,a) || checkTargetsRight(c,a) || checkTargetsLeft(c,a);
		if(a.getCastArea() == AreaOfEffect.SELFTARGET)
			return true;
		if(a.getCastArea() == AreaOfEffect.SINGLETARGET)
			return getTargetSingle(c,a) != null;
		if(a.getCastArea() == AreaOfEffect.SURROUND)
			return checkTargetsSurround(c,a);
		if(a.getCastArea() == AreaOfEffect.TEAMTARGET)
			return checkTargetsTeam(c,a);
		return false;
	}
	
	public boolean checkAttackUp(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			x++;
			if(x == 5)
				break;
			if(board[x][y] != null && board[x][y] instanceof Champion && ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
				return true;	
			else
				if(board[x][y] != null && c.getLocation().x < Target.getLocation().x && board[x][y] instanceof Cover)
					return true;
		}
		return false;
	}
	
	public boolean checkAttackDown(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			x--;
			if(x == -1)
				break;
			if(board[x][y] != null && board[x][y] instanceof Champion && ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
				return true;	
			else
				if(board[x][y] != null && c.getLocation().x > Target.getLocation().x && board[x][y] instanceof Cover)
					return true;
		}
		return false;
	}
	
	public boolean checkAttackRight(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			y++;
			if(y == 5)
				break;
			if(board[x][y] != null && board[x][y] instanceof Champion && ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
				return true;	
			else
				if(board[x][y] != null && c.getLocation().y < Target.getLocation().y && board[x][y] instanceof Cover)
					return true;
		}
		return false;
	}
	
	public boolean checkAttackLeft(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			y--;
			if(y == -1)
				break;
			if(board[x][y] != null && board[x][y] instanceof Champion && ((p1.getTeam().contains(c) && p2.getTeam().contains((Champion)board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion)board[x][y])) )) 
				return true;
			else
				if(board[x][y] != null && board[x][y] instanceof Cover && c.getLocation().y > Target.getLocation().y)
					return true;
		}
		return false;
	}

	public boolean checkLeader(Champion c) {
		if(c instanceof Villain) {
			ArrayList<Champion> x = new ArrayList<Champion>(); 
			if(p1.getTeam().contains(c))
				x = p2.getTeam();
			else
				x = p1.getTeam();
			for(Champion e: x) {
				if(e.getCurrentHP() < (0.3 * e.getMaxHP()))
					return true;
			}
		}
		if(c instanceof Hero) {
			ArrayList<Champion> x = new ArrayList<Champion>(); 
			if(p1.getTeam().contains(c))
				x = p1.getTeam();
			else
				x = p2.getTeam();
			for(Champion e: x) {
				for(Effect d : e.getAppliedEffects())
					if(d.getType() == EffectType.DEBUFF)
						return true;
			}
		}
		if(c instanceof AntiHero)
			return true;
		return false;
	}
	
	public void castAutomatedDirectional(Champion c, Ability a) throws NotEnoughResourcesException, AbilityUseException, CloneNotSupportedException{
		if(checkTargetsUp(c, a)) {
			game.castAbility(a, Direction.UP, grid.Grid, grid);
			if(game.checkGameOver() != null) {
				switchToGameOver();
				return;
	    	}
			updateGame();
			return;
		}
		if(checkTargetsDown(c, a)) {
			game.castAbility(a, Direction.DOWN, grid.Grid, grid);
			if(game.checkGameOver() != null) {
				switchToGameOver();
				return;
	    	}
			updateGame();
			return;
		}
		if(checkTargetsRight(c, a)) {
			game.castAbility(a, Direction.RIGHT, grid.Grid, grid);
			if(game.checkGameOver() != null) {
				switchToGameOver();
				return;
	    	}
			updateGame();
			return;
		}
		if(checkTargetsLeft(c, a)) {
			game.castAbility(a, Direction.LEFT, grid.Grid, grid);
			if(game.checkGameOver() != null) {
				switchToGameOver();
				return;
	    	}
			updateGame();
			return;
		}
	}
	
	public void Ability1(Champion c) {
		try {
			if(c.getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) {
				castAutomatedDirectional(c, c.getAbilities().get(0));
			}
			if(c.getAbilities().get(0).getCastArea() == AreaOfEffect.SURROUND) {
				if(checkTargetsSurround(c, c.getAbilities().get(0))) {
					game.castAbility(c.getAbilities().get(0), grid.Grid, grid);
				}
			}
			if(c.getAbilities().get(0).getCastArea() == AreaOfEffect.TEAMTARGET) {
				if(checkTargetsTeam(c, c.getAbilities().get(0)))
					game.castAbility(c.getAbilities().get(0), grid.Grid, grid);
			}
			if(c.getAbilities().get(0).getCastArea() == AreaOfEffect.SELFTARGET) {
				game.castAbility(c.getAbilities().get(0), grid.Grid, grid);
			}
			if(c.getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET) {
				if(getTargetSingle(c, c.getAbilities().get(0)) != null) {
					game.castAbility(c.getAbilities().get(0), getTargetSingle(c, c.getAbilities().get(0)).getLocation().x, getTargetSingle(c, c.getAbilities().get(0)).getLocation().y, grid.Grid, grid);
				}
			}
			if(game.checkGameOver() != null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 2000;
			    t8.setOnFinished(a -> switchToGameOver());
			    t8.play();
			    return;
	    	}
			updateGame();
		}catch(Exception e) {}
	}
	
	public void Ability2(Champion c) { 
	if(c.getAbilities().get(1).getCurrentCooldown() == 0) {
		try {
			if(c.getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) {
				castAutomatedDirectional(c, c.getAbilities().get(1));
			}
			if(c.getAbilities().get(1).getCastArea() == AreaOfEffect.SURROUND) {
				if(checkTargetsSurround(c, c.getAbilities().get(1)))
					game.castAbility(c.getAbilities().get(1), grid.Grid, grid);
			}
			if(c.getAbilities().get(1).getCastArea() == AreaOfEffect.TEAMTARGET) {
				if(checkTargetsTeam(c, c.getAbilities().get(1)))
					game.castAbility(c.getAbilities().get(1), grid.Grid, grid);
			}
			if(c.getAbilities().get(1).getCastArea() == AreaOfEffect.SELFTARGET) {
				game.castAbility(c.getAbilities().get(1), grid.Grid, grid);
			}
			if(c.getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET) {
				if(getTargetSingle(c, c.getAbilities().get(1)) != null) {
					game.castAbility(c.getAbilities().get(1), c.getLocation().x, c.getLocation().y, grid.Grid, grid);
				}
			}
			if(game.checkGameOver() != null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 2000;
			    t8.setOnFinished(a -> switchToGameOver());
			    t8.play();
			    return;
	    	}
			updateGame();
		}catch(Exception e) {}
	}
	}
	
	public void Ability3(Champion c) {
	if(c.getAbilities().get(2).getCurrentCooldown() == 0) {
		try {
			if(c.getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL) {
				castAutomatedDirectional(c, c.getAbilities().get(2));
			}
			if(c.getAbilities().get(2).getCastArea() == AreaOfEffect.SURROUND) {
				if(checkTargetsSurround(c, c.getAbilities().get(2)))
					game.castAbility(c.getAbilities().get(2), grid.Grid, grid);
			}
			if(c.getAbilities().get(2).getCastArea() == AreaOfEffect.TEAMTARGET) {
				if(checkTargetsTeam(c, c.getAbilities().get(2)))
					game.castAbility(c.getAbilities().get(2), grid.Grid, grid);
			}
			if(c.getAbilities().get(2).getCastArea() == AreaOfEffect.SELFTARGET) {
				game.castAbility(c.getAbilities().get(2), grid.Grid, grid);
			}
			if(c.getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET) {
				if(getTargetSingle(c, c.getAbilities().get(2)) != null) {
					game.castAbility(c.getAbilities().get(2), c.getLocation().x, c.getLocation().y, grid.Grid, grid);
				}
			}
			if(game.checkGameOver() != null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 2000;
			    t8.setOnFinished(a -> switchToGameOver());
			    t8.play();
			    return;
	    	}
			updateGame();
		}catch(Exception e) {}
	}}
	
	public void Leader(Champion c) {
		if(checkLeader(c) && (p1.getLeader().equals(c) || p2.getLeader().equals(c))) {
			try {
				game.useLeaderAbility(grid.Grid, grid);
				player2.a4.setVisible(false);
				player2.a4.setDisable(true);
				if(game.checkGameOver() != null) {
					PauseTransition t8 = new PauseTransition(Duration.millis(timer));
					timer += 2000;
				    t8.setOnFinished(a -> switchToGameOver());
				    t8.play();
				    return;
		    	}
				updateGame();
			} catch (Exception e) {}
		}
	}
	
	public void AttackUp(Champion c) {
		if(checkAttackUp(c, p1.getTeam().get(0))) {
			try {
				game.attack(Direction.UP, grid.Grid, grid);
				if(game.checkGameOver() == null)
					updateGame();
				else {
					switchToGameOver();
					return;
				}
			}catch(Exception e) {}
		}
	}
	
	public void AttackRight(Champion c) {
		if(checkAttackRight(c, p1.getTeam().get(0))) {
			try {
				game.attack(Direction.RIGHT, grid.Grid, grid);
				if(game.checkGameOver() == null)
					updateGame();
				else {
					switchToGameOver();
					return;
				}
			}catch(Exception e) {}
		}
	}
	
	public void AttackLeft(Champion c) {
		if(checkAttackLeft(c, p1.getTeam().get(0))) {
			try {
				game.attack(Direction.LEFT, grid.Grid, grid);
				if(game.checkGameOver() == null)
					updateGame();
				else {
					switchToGameOver();
					return;
				}
			}catch(Exception e) {}
		}
	}
	
	public void AttackDown(Champion c) {
		if(checkAttackDown(c, p1.getTeam().get(0))) {
			try {
				game.attack(Direction.DOWN, grid.Grid, grid);
				if(game.checkGameOver() == null)
					updateGame();
				else {
					switchToGameOver();
					return;
				}
			}catch(Exception e) {}
		}
	}
	
	public void endTurn() {
		setAllFalse();
		game.UpdateGrid(grid.Grid, Hover, grid.health);
		game.endTurn();
		if(p1.getTeam().contains(game.getCurrentChampion()) || !isSinglePlayer) {
			if(p1.getTeam().contains(game.getCurrentChampion())) {
				isFirstPlayer = true;
				isSecondPlayer = false;
			}
			else {
				isFirstPlayer = false;
				isSecondPlayer = true;
			}
			turnOrder.UpdateTurnOrder(game.getTurnOrder());
			if(isFirstPlayer) {
				player2.setOpacity(0.5);
				player2.setDisable(true);
				player1.setDisable(false);
				player1.setOpacity(1);
				player1.Update(game.getCurrentChampion(), p1);
			}
			else {
				player1.setOpacity(0.5);
				player1.setDisable(true);
				player2.setDisable(false);
				player2.setOpacity(1);
				player2.Update(game.getCurrentChampion(), p2);
			}
			if(game.getCurrentChampion().isDisarmed()) {
				Attack.setDisable(true);
				Attack.setVisible(false);
				Punch.setDisable(false);
				Punch.setVisible(true);
				Move.setDisable(false);
				Cast.setDisable(false);
				EndTurn.setDisable(false);
			}
			else {
				Attack.setDisable(false);
				Attack.setVisible(true);
				Punch.setDisable(true);
				Punch.setVisible(false);
				Move.setDisable(false);
				Cast.setDisable(false);
				EndTurn.setDisable(false);
			}
		}
		else {
			if(p1.getTeam().contains(game.getCurrentChampion())) {
				isFirstPlayer = true;
				isSecondPlayer = false;
			}
			else {
				isFirstPlayer = false;
				isSecondPlayer = true;
			}
			turnOrder.UpdateTurnOrder(game.getTurnOrder());
			if(isFirstPlayer) {
				player2.setOpacity(0.5);
				player2.setDisable(true);
				player1.setDisable(false);
				player1.setOpacity(1);
				player1.Update(game.getCurrentChampion(), p1);
			}
			else {
				player1.setOpacity(0.5);
				player1.setDisable(true);
				player2.setDisable(false);
				player2.setOpacity(1);
				player2.Update(game.getCurrentChampion(), p2);
			}
			Move.setDisable(true);
			Cast.setDisable(true);
			EndTurn.setDisable(true);
			Attack.setDisable(true);
			Punch.setDisable(true);
			Champion c = game.getCurrentChampion();
			timer = 250;
			if(game.checkGameOver() == null && validateAbility(c, c.getAbilities().get(0))) {
				PauseTransition t1 = new PauseTransition(Duration.millis(timer));
			    t1.setOnFinished(a -> Ability1(c));
			    t1.play();
			    player1.updateDead();
				player2.updateDead();
				player2.Update(c,p2);
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				timer += 750;
			}
			if(game.checkGameOver() == null && validateAbility(c, c.getAbilities().get(1))) {
			PauseTransition t1 = new PauseTransition(Duration.millis(timer));
		    t1.setOnFinished(a -> Ability2(c));
		    t1.play();
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(game.checkGameOver() == null && validateAbility(c, c.getAbilities().get(2))) {
		    PauseTransition t2 = new PauseTransition(Duration.millis(timer));
		    t2.setOnFinished(a -> Ability3(c));
		    t2.play();
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(game.checkGameOver() == null && !game.isSecondLeaderAbilityUsed() && checkLeader(c)) {
		    PauseTransition t3 = new PauseTransition(Duration.millis(timer));
		    t3.setOnFinished(a -> Leader(c));
		    t3.play();
		    player2.a4.setVisible(false);
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(game.checkGameOver() == null && c.getCurrentActionPoints() >= 2 && validateAttack(c)) {
			PauseTransition t8 = new PauseTransition(Duration.millis(timer));
			timer += 250;
		    t8.setOnFinished(a -> attackAutomated(c));
		    t8.play();
		    return;
			}
			else {
				if(game.checkGameOver() == null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 250;
			    t8.setOnFinished(a -> moveAutomated(c));
			    t8.play();
			    return;
				}
				else
					if(game.checkGameOver() != null) {
						PauseTransition t8 = new PauseTransition(Duration.millis(timer));
						timer += 2000;
					    t8.setOnFinished(a -> switchToGameOver());
					    t8.play();
					    return;
			    	}
			}
			}
	}
	
	public boolean moveDown(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		if(c.getLocation().x > Target.getLocation().x && board[c.getLocation().x-1][c.getLocation().y] == null)
			return true;
		return false;
	}
	
	public boolean moveUp(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		if(c.getLocation().x < Target.getLocation().x && board[c.getLocation().x+1][c.getLocation().y] == null)
			return true;
		return false;
	}
	
	public boolean moveRight(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		if(c.getLocation().y < Target.getLocation().y && board[c.getLocation().x][c.getLocation().y+1] == null)
			return true;
		return false;
	}
	
	public boolean moveLeft(Champion c, Champion Target) {
		Object[][] board = game.getBoard();
		if(c.getLocation().y > Target.getLocation().y && board[c.getLocation().x][c.getLocation().y-1] == null)
			return true;
		return false;
	}
	
	public void moveUp()  {
		try {
			game.move(Direction.UP);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
		}
		updateGame();
	}
	
	public void moveDown()  {
		try {
			game.move(Direction.DOWN);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
		}
		updateGame();
	}
	
	public void moveRight()  {
		try {
			game.move(Direction.RIGHT);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
		}
		updateGame();
	}
	
	public void moveLeft()  {
		try {
			game.move(Direction.LEFT);
		} catch (NotEnoughResourcesException | UnallowedMovementException e) {
		}
		updateGame();
	}
	
	public boolean validateMove(Champion c1, Champion c2) {
		if(c2 == null)
			return false;
		return (moveUp(c1,c2) || moveDown(c1,c2) || moveRight(c1,c2) || moveLeft(c1,c2)) && game.checkGameOver() == null;
	}
	
	public boolean validateAttack(Champion c) {
		return game.checkGameOver() == null && (checkAttackUp(c, p1.getTeam().get(0)) || checkAttackRight(c, p1.getTeam().get(0)) || checkAttackLeft(c, p1.getTeam().get(0)) || checkAttackDown(c, p1.getTeam().get(0)));
	}
	
	public void attackAutomated(Champion c) {
		if(game.checkGameOver() == null && checkAttackUp(c, p1.getTeam().get(0)) && c.getCurrentActionPoints() >= 2 ) {
		    PauseTransition t4 = new PauseTransition(Duration.millis(timer));
		    t4.setOnFinished(a -> AttackUp(c));
		    t4.play();
			timer += 150;
			}
			if(game.checkGameOver() == null && checkAttackRight(c, p1.getTeam().get(0)) && c.getCurrentActionPoints() >= 2 ) {
		    PauseTransition t5 = new PauseTransition(Duration.millis(timer));
		    t5.setOnFinished(a -> AttackRight(c));
		    t5.play();
			timer += 150;
			}
			if(game.checkGameOver() == null && checkAttackLeft(c, p1.getTeam().get(0)) && c.getCurrentActionPoints() >= 2) {
		    PauseTransition t6 = new PauseTransition(Duration.millis(timer));
		    t6.setOnFinished(a -> AttackLeft(c));
		    t6.play();
			timer += 150;
			}
			if(game.checkGameOver() == null && checkAttackDown(c, p1.getTeam().get(0)) && c.getCurrentActionPoints() >= 2) {
		    PauseTransition t7 = new PauseTransition(Duration.millis(timer));
		    t7.setOnFinished(a -> AttackDown(c));
		    t7.play();
		    timer += 150;
			}
			if(game.checkGameOver() != null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 2000;
			    t8.setOnFinished(a -> switchToGameOver());
			    t8.play();
			    return;
	    	}
			if(c.getCurrentActionPoints() >= 2 && validateAttack(c)) {
			    PauseTransition t9 = new PauseTransition(Duration.millis(timer));
				timer += 150;
			    t9.setOnFinished(a -> attackAutomated(c));
			    t9.play();
			    return;
				}
				else {
					PauseTransition t9 = new PauseTransition(Duration.millis(timer));
					timer += 150;
				    t9.setOnFinished(a -> moveAutomated(c));
				    t9.play();
				    return;
				}
	}

	public void moveAutomated(Champion c) {
		Champion target = p1.getTeam().get(0);
		int index = p2.getIndex(c);
		switch(index) {
		case 1:
			if(p1.getTeam().size() >= 2)
				target = p1.getTeam().get(1);
			break;
		case 2: 
			if(p1.getTeam().size() == 3)
				target = p1.getTeam().get(2);
			else
				if(p1.getTeam().size() == 2)
					target = p1.getTeam().get(1);
			break;
		}
		if(moveUp(c, target) && c.getCurrentActionPoints() >= 1 && game.checkGameOver() == null) {
		    PauseTransition t4 = new PauseTransition(Duration.millis(timer));
		    t4.setOnFinished(a -> moveUp());
		    t4.play();
			timer += 150;
		}
		if(moveDown(c, target) && c.getCurrentActionPoints() >= 1 && game.checkGameOver() == null) {
		    PauseTransition t7 = new PauseTransition(Duration.millis(timer));
		    t7.setOnFinished(a -> moveDown());
		    t7.play();
		    timer += 150;
		}
		if(moveRight(c, target) && c.getCurrentActionPoints() >= 1 && game.checkGameOver() == null) {
		    PauseTransition t5 = new PauseTransition(Duration.millis(timer));
		    t5.setOnFinished(a -> moveRight());
		    t5.play();
			timer += 150;
		}
		if(moveLeft(c, target) && c.getCurrentActionPoints() >= 1 && game.checkGameOver() == null) {
		    PauseTransition t6 = new PauseTransition(Duration.millis(timer));
		    t6.setOnFinished(a -> moveLeft());
		    t6.play();
		}
		if(c.getCurrentActionPoints() >= 2 && validateAttack(c) && game.checkGameOver() == null) {
			PauseTransition t9 = new PauseTransition(Duration.millis(timer));
			timer += 150;
			t9.setOnFinished(a -> attackAutomated(c));
			t9.play();
			return;
		}
		if(c.getCurrentActionPoints() >= 1 && validateMove(c, target) && game.checkGameOver() == null) {
		    PauseTransition t9 = new PauseTransition(Duration.millis(timer));
			timer += 150;
		    t9.setOnFinished(a -> moveAutomated(c));
		    t9.play();
		    return;
		}
		else {
			if(game.checkGameOver() == null) {
				PauseTransition t9 = new PauseTransition(Duration.millis(100));
			    t9.setOnFinished(a -> endTurn());
			    t9.play();
			    return;
			}
		    else
		    	if(game.checkGameOver() != null) {
		    		PauseTransition t8 = new PauseTransition(Duration.millis(timer));
					timer += 2000;
				    t8.setOnFinished(a -> switchToGameOver());
				    t8.play();
				    return;
		    	}
		}
	}
	
	public void switchToGamePane() {
		game = new Game(p1, p2);
		GamePane = new AnchorPane1(1,1);
		GamePane.setStyle("-fx-background-image: url('/images/BG.gif');");
		grid = new GridPane1(500, 500, 518, 182);
		turnOrder = new TurnOrderPane();
		player1 = new Player1(p1);
		player2 = new Player2(p2);
		Hover = new Label1(478, 472, 5, 209, "", "game");
		GamePane.getChildren().add(player1);
		GamePane.getChildren().add(player2);
		player1.Update(p1.getHighestSpeed(), p1);
		player2.Update(p2.getHighestSpeed(), p2);
		if(p1.getTeam().contains(game.getCurrentChampion())) {
			player2.setOpacity(0.5);
			player2.setDisable(true);
		}
		else {
			player1.setOpacity(0.5);
			player1.setDisable(true);
		}
		if(p1.getTeam().contains(game.getCurrentChampion()))
			isFirstPlayer = true;
		else
			isSecondPlayer = true;
		game.UpdateGrid(grid.Grid, Hover, grid.health);
		turnOrder.UpdateTurnOrder(game.getTurnOrder());
		EndTurn = new Button1(509, "END TURN");
		Settings = new Button1(459, "SETTINGS");
		Settings.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				switchToSettings();
				game.UpdateGrid(grid.Grid, Hover, grid.health);
			}
		});
		player1.Champion.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "ATTACK RANGE: " + game.getCurrentChampion().getAttackRange() + "\nATTACK DAMAGE: " + game.getCurrentChampion().getAttackDamage();
				if(!game.getCurrentChampion().getAppliedEffects().isEmpty()) {
					r  += "\nAPPLIED EFFECTS \"NAME(DURATION)\": ";
					for(Effect e: game.getCurrentChampion().getAppliedEffects()) {
						r = r + "\n" + e.getName() + "(" + e.getDuration() + ")";
					}
				}
				if(!(player1.isSelected() || player2.isSelected()))
					Hover.setText(r);
			}
		});
		player2.Champion.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "ATTACK RANGE: " + game.getCurrentChampion().getAttackRange() + "\nATTACK DAMAGE: " + game.getCurrentChampion().getAttackDamage();
				if(!game.getCurrentChampion().getAppliedEffects().isEmpty()) {
					r  += "\nAPPLIED EFFECTS \"NAME(DURATION)\": ";
					for(Effect e: game.getCurrentChampion().getAppliedEffects()) {
						r = r + "\n" + e.getName() + "(" + e.getDuration() + ")";
					}
				}
				if(!(player1.isSelected() || player2.isSelected()))
					Hover.setText(r);
			}
		});
		Cast = new Button1(409, "CAST");
		Cast.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				action = 0;
				if(fourthAbility) {
					try {
						game.useLeaderAbility(grid.Grid, grid);
						game.UpdateGrid(grid.Grid, Hover, grid.health);
						setAllFalse();
						if(game.checkGameOver() != null)
							switchToGameOver();
						if(isFirstPlayer) { 
							player1.a4.setVisible(false);
							player1.a4.setDisable(true);
						}
						else {
							player2.a4.setVisible(false);
							player1.a4.setDisable(true);
						}
					}
					catch(LeaderNotCurrentException e) {
						ExceptionPane a = new ExceptionPane(e.getMessage().toUpperCase());
						GamePane.getChildren().add(a);
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
					catch(LeaderAbilityAlreadyUsedException e) {
						ExceptionPane a = new ExceptionPane(e.getMessage().toUpperCase());
						GamePane.getChildren().add(a);
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
				}
				else {
					Ability a;
					if(firstAbility) {
						a = game.getCurrentChampion().getAbilities().get(0);
						}
					else {
						if(secondAbility) {
							a = game.getCurrentChampion().getAbilities().get(1);
						}
						else {
							if(thirdAbility)
								a = game.getCurrentChampion().getAbilities().get(2);
							else
								if(punchAbility) {
									a = game.getCurrentChampion().getAbility("Punch");
									punchPressed = false;
								}
								else
									return;
						}
					}
					if(a.getCastArea() == AreaOfEffect.DIRECTIONAL) {
						castDirectional(a);
						setAllFalse();
					}
					else {
						if(a.getCastArea() == AreaOfEffect.SINGLETARGET) {
							castSelf(a);
							setAllFalse();
							player1.updateDead();
							player2.updateDead();
						}
						else {
							try {
								game.castAbility(a, grid.Grid, grid);
								game.UpdateGrid(grid.Grid, Hover, grid.health);
								player1.updateDead();
								player2.updateDead();
								if(isFirstPlayer)
									player1.Update(game.getCurrentChampion(), p1);
								else
									player2.Update(game.getCurrentChampion(), p2);
								setAllFalse();
								if(game.checkGameOver() != null)
									switchToGameOver();
							}
							catch(NotEnoughResourcesException u) {
								ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
								GamePane.getChildren().add(b);
								Hover.setText("");
								game.UpdateGrid(grid.Grid, Hover, grid.health);
							}
							catch(AbilityUseException u) {
								ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
								GamePane.getChildren().add(b);
								Hover.setText("");
								game.UpdateGrid(grid.Grid, Hover, grid.health);
							}
							catch(CloneNotSupportedException u) {
								ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
								GamePane.getChildren().add(b);
								Hover.setText("");
								game.UpdateGrid(grid.Grid, Hover, grid.health);
							}
						}
					}
				}
				player1.setNotSelected();
				player2.setNotSelected();
				Hover.setText("");
			}
		});
		Move = new Button1(309, "MOVE");
		Attack = new Button1(359, "ATTACK");
		Punch = new Button1(359, "PUNCH");
		Punch.setVisible(false);
		Punch.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: PUNCH" + "\nTYPE: DMG" + "\nCAST AREA: SINGLETARGET" + "\nCAST RANGE: 1" + "\nMANA COST: 0" + "\nACTION POINTS COST: 1" + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(3).getCurrentCooldown() + "\nBASE COOLDOWN: 1";
				r = r + "\nDAMAGE AMOUNT: 50";
				if(!punchPressed)
					Hover.setText(r);
			}
		});
		Punch.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!punchPressed)
					Hover.setText("");
			}
		});
		Punch.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				punchPressed = true;
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				singleWhite(game.getCurrentChampion().getAbility("Punch"));
				setAllFalse();
				player1.setNotSelected();
				player2.setNotSelected();
				punchAbility = true;
				Hover.setText("CHOOSE CELL THEN PRESS CAST");
			}
		});
		Attack.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				attackWhite();
				action = 0;
				player1.setNotSelected();
				player2.setNotSelected();
				Hover.setText("CHOOSE DIRECTION USING\n   W\n A S D");
				if(p1.getTeam().contains(game.getCurrentChampion()))
					isFirstPlayer = true;
				else
					isSecondPlayer = true;
				attack(grid);
				setAllFalse();
			}
		});
		Move.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				moveWhite();
				action = 0;
				player1.setNotSelected();
				player2.setNotSelected();
				Hover.setText("CHOOSE DIRECTION USING\n   W\n A S D");
				if(p1.getTeam().contains(game.getCurrentChampion()))
					isFirstPlayer = true;
				else
					isSecondPlayer = true;
				move(grid);
				setAllFalse();
			}
		});
		EndTurn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				endTurn();
			}
			
		});
		player1.a1.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(0));
				else
					if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(0));
					else
						if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(0));
						else
							if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(0));
							else
								if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(0));
				setAllFalse();
				player1.setNotSelected();
				player1.a1.setSelected(true);
				firstAbility = true;
				if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) {
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				}
				else {
					if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player1.a2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(1));
				else
					if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(1));
					else
						if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(1));
						else
							if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(1));
							else
								if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(1));
				setAllFalse();
				secondAbility = true;
				player1.setNotSelected();
				player1.a2.setSelected(true);
				if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) {
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				}
				else {
					if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player1.a3.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(2));
				else
					if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(2));
					else
						if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(2));
						else
							if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(2));
							else
								if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(2));
				setAllFalse();
				thirdAbility = true;
				player1.setNotSelected();
				player1.a3.setSelected(true);
				if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL)
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				else {
					if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player2.a1.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(0));
				else
					if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(0));
					else
						if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(0));
						else
							if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(0));
							else
								if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(0));
				setAllFalse();
				firstAbility = true;
				player2.setNotSelected();
				player2.a1.setSelected(true);
				if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.DIRECTIONAL)
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				else {
					if(game.getCurrentChampion().getAbilities().get(0).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player2.a2.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(1));
				else
					if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(1));
					else
						if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(1));
						else
							if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(1));
							else
								if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(1));
				setAllFalse();
				secondAbility = true;
				player2.setNotSelected();
				player2.a2.setSelected(true);
				if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.DIRECTIONAL)
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				else {
					if(game.getCurrentChampion().getAbilities().get(1).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player2.a3.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SURROUND) 
					surroundWhite(game.getCurrentChampion().getAbilities().get(2));
				else
					if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL) 
						directionalWhite(game.getCurrentChampion().getAbilities().get(2));
					else
						if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SELFTARGET) 
							selfWhite(game.getCurrentChampion().getAbilities().get(2));
						else
							if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET) 
								singleWhite(game.getCurrentChampion().getAbilities().get(2));
							else
								if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.TEAMTARGET) 
									teamWhite(game.getCurrentChampion().getAbilities().get(2));
				setAllFalse();
				thirdAbility = true;
				player2.setNotSelected();
				player2.a3.setSelected(true);
				if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.DIRECTIONAL)
					Hover.setText("PRESS CAST\nTHEN CHOOSE DIRECTION USING\n   W\n A S D");
				else {
					if(game.getCurrentChampion().getAbilities().get(2).getCastArea() == AreaOfEffect.SINGLETARGET)
						Hover.setText("CHOOSE CELL THEN PRESS CAST");
					else
						Hover.setText("PRESS CAST");
				}
			}
		});
		player2.a4.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				setAllFalse();
				fourthAbility = true;
				player2.setNotSelected();
				player2.a4.setSelected(true);
				Hover.setText("PRESS CAST");
			}
		});
		player1.a4.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				setAllFalse();
				fourthAbility = true;
				player1.setNotSelected();
				player1.a4.setSelected(true);
				Hover.setText("PRESS CAST");
			}
		});
		player1.a1.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(0).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(0).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(0).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(0).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(0).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(0).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(0).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(0).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(0) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(0)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(0) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(0)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(0) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(0)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(0)).getEffect().getDuration() + ")";
				if(!player1.isSelected())
					Hover.setText(r);
			}
		});
		player1.a2.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(1).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(1).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(1).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(1).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(1).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(1).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(1).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(1).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(1) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(1)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(1) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(1)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(1) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(1)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(1)).getEffect().getDuration() + ")";
				if(!player1.isSelected())
					Hover.setText(r);
			}	
		});
		player1.a3.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(2).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(2).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(2).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(2).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(2).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(2).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(2).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(2).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(2) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(2)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(2) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(2)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(2) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(2)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(2)).getEffect().getDuration() + ")";
				if(!player1.isSelected())
					Hover.setText(r);
			}
		});
		player2.a1.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(0).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(0).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(0).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(0).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(0).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(0).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(0).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(0).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(0) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(0)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(0) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(0)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(0) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(0)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(0)).getEffect().getDuration() + ")";
				if(!player2.isSelected())
					Hover.setText(r);
			}
		});
		player2.a2.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(1).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(1).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(1).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(1).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(1).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(1).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(1).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(1).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(1) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(1)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(1) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(1)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(1) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(1)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(1)).getEffect().getDuration() + ")";
				if(!player2.isSelected())
					Hover.setText(r);
			}	
		});
		player2.a3.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "NAME: " + game.getCurrentChampion().getAbilities().get(2).getName() + "\nTYPE: " + game.getCurrentChampion().getAbilities().get(2).getType() + "\nCAST AREA: " + game.getCurrentChampion().getAbilities().get(2).getCastArea() + "\nCAST RANGE: " + game.getCurrentChampion().getAbilities().get(2).getCastRange() + "\nMANA COST: " + game.getCurrentChampion().getAbilities().get(2).getManaCost() + "\nACTION POINTS COST: " + game.getCurrentChampion().getAbilities().get(2).getRequiredActionPoints() + "\nCURRENT COOLDOWN: " + game.getCurrentChampion().getAbilities().get(2).getCurrentCooldown() + "\nBASE COOLDOWN: " + game.getCurrentChampion().getAbilities().get(2).getBaseCooldown();
				if(game.getCurrentChampion().getAbilities().get(2) instanceof HealingAbility)
					r = r + "\nHEALING AMOUNT: " + ((HealingAbility)game.getCurrentChampion().getAbilities().get(2)).getHealAmount();
				else
					if(game.getCurrentChampion().getAbilities().get(2) instanceof DamagingAbility)
						r = r + "\nDAMAGE AMOUNT: " + ((DamagingAbility)game.getCurrentChampion().getAbilities().get(2)).getDamageAmount();
					else
						if(game.getCurrentChampion().getAbilities().get(2) instanceof CrowdControlAbility)
							r = r + "\nEFFECT NAME(DURATION): " + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(2)).getEffect().getName() + "(" + ((CrowdControlAbility)game.getCurrentChampion().getAbilities().get(2)).getEffect().getDuration() + ")";
				if(!player2.isSelected())
					Hover.setText(r);
			}
		});
		player2.a4.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "";
				if(game.getCurrentChampion() instanceof Hero)
					r = "Removes all negative effects from the player�s entire team and adds an Embrace effect to them which lasts for 2 turns";
				if(game.getCurrentChampion() instanceof AntiHero)
					r = "All champions on the board except for the leaders of each team will be stunned for 2 turns";
				if(game.getCurrentChampion() instanceof Villain)
					r = "Immediately eliminates (knocks out) all enemy champions with less than 30% health points";
				if(!player2.isSelected())
					Hover.setText(r.toUpperCase());
			}
		});
		player1.a4.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				String r = "";
				if(game.getCurrentChampion() instanceof Hero)
					r = "Removes all negative effects from the player�s entire team and adds an Embrace effect to them which lasts for 2 turns";
				if(game.getCurrentChampion() instanceof AntiHero)
					r = "All champions on the board except for the leaders of each team will be stunned for 2 turns";
				if(game.getCurrentChampion() instanceof Villain)
					r = "Immediately eliminates (knocks out) all enemy champions with less than 30% health points";
				if(!player1.isSelected())
					Hover.setText(r.toUpperCase());
			}
		});
		player1.a4.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player1.isSelected())
					Hover.setText("");
			}
		});
		player1.a3.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player1.isSelected())
					Hover.setText("");
			}
		});
		player1.a2.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player1.isSelected())
					Hover.setText("");
			}
		});
		player1.a1.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player1.isSelected())
					Hover.setText("");
			}
		});
		player2.a4.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player2.isSelected())
					Hover.setText("");
			}
		});
		player2.a3.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player2.isSelected())
					Hover.setText("");
			}
		});
		player2.a2.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player2.isSelected())
					Hover.setText("");
			}
		});
		player2.a1.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!player2.isSelected())
					Hover.setText("");
			}
		});
		player1.Champion.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected()))
					Hover.setText("");
			}
		});
		player2.Champion.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected()))
					Hover.setText("");
			}
		});
		grid.aa.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.aa)][grid.getJ(grid.aa)] != null) {
						if(board[grid.getI(grid.aa)][grid.getJ(grid.aa)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.aa)][grid.getJ(grid.aa)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.aa)][grid.getJ(grid.aa)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.aa.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ab.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ab)][grid.getJ(grid.ab)] != null) {
						if(board[grid.getI(grid.ab)][grid.getJ(grid.ab)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ab)][grid.getJ(grid.ab)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ab)][grid.getJ(grid.ab)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ab.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ac.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ac)][grid.getJ(grid.ac)] != null) {
						if(board[grid.getI(grid.ac)][grid.getJ(grid.ac)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ac)][grid.getJ(grid.ac)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ac)][grid.getJ(grid.ac)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ac.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ad.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ad)][grid.getJ(grid.ad)] != null) {
						if(board[grid.getI(grid.ad)][grid.getJ(grid.ad)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ad)][grid.getJ(grid.ad)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ad)][grid.getJ(grid.ad)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ad.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ae.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ae)][grid.getJ(grid.ae)] != null) {
						if(board[grid.getI(grid.ae)][grid.getJ(grid.ae)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ae)][grid.getJ(grid.ae)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ae)][grid.getJ(grid.ae)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ae.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ba.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ba)][grid.getJ(grid.ba)] != null) {
						if(board[grid.getI(grid.ba)][grid.getJ(grid.ba)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ba)][grid.getJ(grid.ba)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ba)][grid.getJ(grid.ba)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ba.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.bb.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.bb)][grid.getJ(grid.bb)] != null) {
						if(board[grid.getI(grid.bb)][grid.getJ(grid.bb)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.bb)][grid.getJ(grid.bb)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.bb)][grid.getJ(grid.bb)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.bb.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.bc.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.bc)][grid.getJ(grid.bc)] != null) {
						if(board[grid.getI(grid.bc)][grid.getJ(grid.bc)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.bc)][grid.getJ(grid.bc)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.bc)][grid.getJ(grid.bc)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.bc.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.bd.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.bd)][grid.getJ(grid.bd)] != null) {
						if(board[grid.getI(grid.bd)][grid.getJ(grid.bd)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.bd)][grid.getJ(grid.bd)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.bd)][grid.getJ(grid.bd)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.bd.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.be.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.be)][grid.getJ(grid.be)] != null) {
						if(board[grid.getI(grid.be)][grid.getJ(grid.be)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.be)][grid.getJ(grid.be)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.be)][grid.getJ(grid.be)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.be.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ca.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ca)][grid.getJ(grid.ca)] != null) {
						if(board[grid.getI(grid.ca)][grid.getJ(grid.ca)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ca)][grid.getJ(grid.ca)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ca)][grid.getJ(grid.ca)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ca.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.cb.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.cb)][grid.getJ(grid.cb)] != null) {
						if(board[grid.getI(grid.cb)][grid.getJ(grid.cb)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.cb)][grid.getJ(grid.cb)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.cb)][grid.getJ(grid.cb)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.cb.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.cc.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.cc)][grid.getJ(grid.cc)] != null) {
						if(board[grid.getI(grid.cc)][grid.getJ(grid.cc)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.cc)][grid.getJ(grid.cc)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.cc)][grid.getJ(grid.cc)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.cc.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.cd.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.cd)][grid.getJ(grid.cd)] != null) {
						if(board[grid.getI(grid.cd)][grid.getJ(grid.cd)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.cd)][grid.getJ(grid.cd)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.cd)][grid.getJ(grid.cd)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.cd.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ce.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ce)][grid.getJ(grid.ce)] != null) {
						if(board[grid.getI(grid.ce)][grid.getJ(grid.ce)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ce)][grid.getJ(grid.ce)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ce)][grid.getJ(grid.ce)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ce.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.da.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.da)][grid.getJ(grid.da)] != null) {
						if(board[grid.getI(grid.da)][grid.getJ(grid.da)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.da)][grid.getJ(grid.da)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.da)][grid.getJ(grid.da)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.da.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.db.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.db)][grid.getJ(grid.db)] != null) {
						if(board[grid.getI(grid.db)][grid.getJ(grid.db)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.db)][grid.getJ(grid.db)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.db)][grid.getJ(grid.db)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.db.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.dc.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.dc)][grid.getJ(grid.dc)] != null) {
						if(board[grid.getI(grid.dc)][grid.getJ(grid.dc)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.dc)][grid.getJ(grid.dc)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.dc)][grid.getJ(grid.dc)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.dc.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.dd.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.dd)][grid.getJ(grid.dd)] != null) {
						if(board[grid.getI(grid.dd)][grid.getJ(grid.dd)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.dd)][grid.getJ(grid.dd)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.dd)][grid.getJ(grid.dd)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.dd.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.de.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.de)][grid.getJ(grid.de)] != null) {
						if(board[grid.getI(grid.de)][grid.getJ(grid.de)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.de)][grid.getJ(grid.de)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.de)][grid.getJ(grid.de)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.de.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ea.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ea)][grid.getJ(grid.ea)] != null) {
						if(board[grid.getI(grid.ea)][grid.getJ(grid.ea)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ea)][grid.getJ(grid.ea)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ea)][grid.getJ(grid.ea)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ea.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.eb.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.eb)][grid.getJ(grid.eb)] != null) {
						if(board[grid.getI(grid.eb)][grid.getJ(grid.eb)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.eb)][grid.getJ(grid.eb)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.eb)][grid.getJ(grid.eb)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.eb.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ec.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ec)][grid.getJ(grid.ec)] != null) {
						if(board[grid.getI(grid.ec)][grid.getJ(grid.ec)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ec)][grid.getJ(grid.ec)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ec)][grid.getJ(grid.ec)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ec.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ed.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ed)][grid.getJ(grid.ed)] != null) {
						if(board[grid.getI(grid.ed)][grid.getJ(grid.ed)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ed)][grid.getJ(grid.ed)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ed)][grid.getJ(grid.ed)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ed.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		grid.ee.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Object[][] board = game.getBoard();
					if(board[grid.getI(grid.ee)][grid.getJ(grid.ee)] != null) {
						if(board[grid.getI(grid.ee)][grid.getJ(grid.ee)] instanceof Cover)
							Hover.setText("HP: " + ((Cover)board[grid.getI(grid.ee)][grid.getJ(grid.ee)]).getCurrentHP());
						else {
							Champion c = (Champion) board[grid.getI(grid.ee)][grid.getJ(grid.ee)];
							String r = c.getName().toUpperCase() + "\nTYPE: " + c.getType() + "\nHP: " + c.getCurrentHP() + "\nMANA: " + c.getMana() + "\nACTION POINTS: " + c.getMaxActionPointsPerTurn() + "\nSPEED: " + c.getSpeed() + "\nATTACK RANGE: " + c.getAttackRange() + "\nATTACK DAMAGE: " + c.getAttackDamage() ;
							if(c.equals(p1.getLeader()) || c.equals(p2.getLeader()))
								r += "\nLEADER";
							if(!c.getAppliedEffects().isEmpty()) {
								r += "\nAPPLIED EFFECTS: \nNAME(DURATION)";
								for(Effect e : c.getAppliedEffects()) {
									r += "\n" + e.getName().toUpperCase() + "(" + e.getDuration() + ")";
								}
							}
				    		Hover.setText(r);
						}
					}
				}
			}
		});
		grid.ee.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if(!(player1.isSelected() || player2.isSelected())) {
					Hover.setText("");
				}
			}
		});
		GamePane.getChildren().add(grid);
		GamePane.getChildren().add(turnOrder);
		GamePane.getChildren().add(Cast);
		GamePane.getChildren().add(EndTurn);
		GamePane.getChildren().add(Move);
		GamePane.getChildren().add(Settings);
		GamePane.getChildren().add(Attack);
		GamePane.getChildren().add(Hover);
		GamePane.getChildren().add(Punch);
		SetLayout5();
		
		Scene = new Scene(GamePane, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
    	Scene.setFill(Color.BLACK);
		stage.setScene(Scene);
		stage.setFullScreen(true);
		stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
		stage.show();
		GamePane.setOpacity(0);
		FadeIn(GamePane);
		if(p2.getTeam().contains(game.getCurrentChampion()) && isSinglePlayer) {
			if(p1.getTeam().contains(game.getCurrentChampion())) {
				isFirstPlayer = true;
				isSecondPlayer = false;
			}
			else {
				isFirstPlayer = false;
				isSecondPlayer = true;
			}
			turnOrder.UpdateTurnOrder(game.getTurnOrder());
			if(isFirstPlayer) {
				player2.setOpacity(0.5);
				player2.setDisable(true);
				player1.setDisable(false);
				player1.setOpacity(1);
				player1.Update(game.getCurrentChampion(), p1);
			}
			else {
				player1.setOpacity(0.5);
				player1.setDisable(true);
				player2.setDisable(false);
				player2.setOpacity(1);
				player2.Update(game.getCurrentChampion(), p2);
			}
			Move.setDisable(true);
			Cast.setDisable(true);
			EndTurn.setDisable(true);
			Attack.setDisable(true);
			Punch.setDisable(true);
			Champion c = game.getCurrentChampion();
			timer = 250;
			if(validateAbility(c, c.getAbilities().get(0)) && game.checkGameOver() == null) {
				PauseTransition t1 = new PauseTransition(Duration.millis(timer));
			    t1.setOnFinished(a -> Ability1(c));
			    t1.play();
			    player1.updateDead();
				player2.updateDead();
				player2.Update(c,p2);
				game.UpdateGrid(grid.Grid, Hover, grid.health);
				timer += 750;
			}
			if(validateAbility(c, c.getAbilities().get(1)) && game.checkGameOver() == null) {
			PauseTransition t1 = new PauseTransition(Duration.millis(timer));
		    t1.setOnFinished(a -> Ability2(c));
		    t1.play();
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(validateAbility(c, c.getAbilities().get(2)) && game.checkGameOver() == null) {
		    PauseTransition t2 = new PauseTransition(Duration.millis(timer));
		    t2.setOnFinished(a -> Ability3(c));
		    t2.play();
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(!game.isSecondLeaderAbilityUsed() && checkLeader(c) && game.checkGameOver() == null) {
		    PauseTransition t3 = new PauseTransition(Duration.millis(timer));
		    t3.setOnFinished(a -> Leader(c));
		    t3.play();
		    player1.updateDead();
			player2.updateDead();
			player2.Update(c,p2);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			timer += 750;
			}
			if(c.getCurrentActionPoints() >= 2 && validateAttack(c) && game.checkGameOver() == null) {
			PauseTransition t8 = new PauseTransition(Duration.millis(timer));
			timer += 250;
		    t8.setOnFinished(a -> attackAutomated(c));
		    t8.play();
		    return;
			}
			else {
				if(game.checkGameOver() == null) {
				PauseTransition t8 = new PauseTransition(Duration.millis(timer));
				timer += 250;
			    t8.setOnFinished(a -> moveAutomated(c));
			    t8.play();
			    return;
				}
				else
					if(game.checkGameOver() != null) {
						switchToGameOver();
						return;
			    	}
			}
		}
	}
	
	public void setAllFalse() {
		firstAbility = false;
		secondAbility = false;
		thirdAbility = false;
		fourthAbility = false;
		punchAbility = false;
	}

	public void castDirectional(Ability a) {
		GamePane.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle(KeyEvent event) {
				if(action == 0) {
					if(event.getCode().equals(KeyCode.W) || event.getCode().equals(KeyCode.UP)) {
						directionalHelper(a, model.world.Direction.UP);
						action++;
						castDirectional(a);
					}
					else {
						if(event.getCode().equals(KeyCode.S) || event.getCode().equals(KeyCode.DOWN)) {
							directionalHelper(a, model.world.Direction.DOWN);
							action++;
							castDirectional(a);
						}
						else {
							if(event.getCode().equals(KeyCode.D) || event.getCode().equals(KeyCode.RIGHT)) {
								directionalHelper(a, model.world.Direction.RIGHT);
								action++;
								castDirectional(a);
							}
							else {
								if(event.getCode().equals(KeyCode.A) || event.getCode().equals(KeyCode.LEFT)) {
									directionalHelper(a, model.world.Direction.LEFT);
									action++;
									castDirectional(a);
								}
							}
						}
					}
				}
			}
        });
		
	}
	
	public void castSelf(Ability a) {
		for(int i = 0; i < 5; i++) {
			for(int j = 0; j < 5; j++) {
				if(grid.Grid[i][j].isSelected()) {
					try {
						game.castAbility(a, i, j, grid.Grid, grid);
						game.UpdateGrid(grid.Grid, Hover, grid.health);
						player1.updateDead();
						player2.updateDead();
						if(isFirstPlayer)
							player1.Update(game.getCurrentChampion(), p1);
						else
							player2.Update(game.getCurrentChampion(), p2);
						if(game.checkGameOver() != null)
							switchToGameOver();
						break;
					}
					catch(NotEnoughResourcesException u) {
						ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
						GamePane.getChildren().add(b);
						Hover.setText("");
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
					catch(AbilityUseException u) {
						ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
						GamePane.getChildren().add(b);
						Hover.setText("");
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
					catch(CloneNotSupportedException u) {
						ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
						GamePane.getChildren().add(b);
						Hover.setText("");
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
					catch(InvalidTargetException u) {
						ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
						GamePane.getChildren().add(b);
						Hover.setText("");
						game.UpdateGrid(grid.Grid, Hover, grid.health);
					}
				}
			}
		}
	}
	
	public void move(GridPane1 grid) {
		GamePane.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle(KeyEvent event) {
				if(action == 0) {
					if(event.getCode().equals(KeyCode.W) || event.getCode().equals(KeyCode.UP)) {
						moveHelper(model.world.Direction.UP);
						action++;
						move(grid);
					}
					else {
						if(event.getCode().equals(KeyCode.S) || event.getCode().equals(KeyCode.DOWN)) {
							moveHelper(model.world.Direction.DOWN);
							action++;
							move(grid);
						}
						else {
							if(event.getCode().equals(KeyCode.D) || event.getCode().equals(KeyCode.RIGHT)) {
								moveHelper(model.world.Direction.RIGHT);
								action++;
								move(grid);
							}
							else {
								if(event.getCode().equals(KeyCode.A) || event.getCode().equals(KeyCode.LEFT)) {
									moveHelper(model.world.Direction.LEFT);
									action++;
									move(grid);
								}
							}
						}
					}
				}
			}
        });
		
	}
	
	public void attack(GridPane1 grid) {
		GamePane.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle(KeyEvent event) {
				if(action == 0) {
					if(event.getCode().equals(KeyCode.W) || event.getCode().equals(KeyCode.UP)) {
						attackHelper(model.world.Direction.UP);
						action++;
						attack(grid);
					}
					else {
						if(event.getCode().equals(KeyCode.S) || event.getCode().equals(KeyCode.DOWN)) {
							attackHelper(model.world.Direction.DOWN);
							action++;
							attack(grid);
						}
						else {
							if(event.getCode().equals(KeyCode.D) || event.getCode().equals(KeyCode.RIGHT)) {
								attackHelper(model.world.Direction.RIGHT);
								action++;
								attack(grid);
							}
							else {
								if(event.getCode().equals(KeyCode.A) || event.getCode().equals(KeyCode.LEFT)) {
									attackHelper(model.world.Direction.LEFT);
									action++;
									attack(grid);
								}
							}
						}
					}
				}
			}
        });
		
	}
	
	public void directionalHelper(Ability a, model.world.Direction d) {
		try {
			game.castAbility(a, d, grid.Grid, grid);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			player1.updateDead();
			player2.updateDead();
			if(isFirstPlayer)
				player1.Update(game.getCurrentChampion(), p1);
			else
				player2.Update(game.getCurrentChampion(), p2);
			if(game.checkGameOver() != null)
				switchToGameOver();
		}
		catch(NotEnoughResourcesException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
		catch(AbilityUseException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
		catch(CloneNotSupportedException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
	}
	
	public void attackHelper(model.world.Direction d) {
		try {
			game.attack(d, grid.Grid, grid);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			player1.updateDead();
			player2.updateDead();
			if(isFirstPlayer)
				player1.Update(game.getCurrentChampion(), p1);
			else
				player2.Update(game.getCurrentChampion(), p2);
			if(game.checkGameOver() != null)
				switchToGameOver();
		}
		catch(ChampionDisarmedException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
		catch(NotEnoughResourcesException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
		catch(InvalidTargetException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);
		}
	}
	
	public void switchToGameOver() {
		gameOver = new GameOver();
		gameOver.MainMenu.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isGamePane = true;
				FadeOut(GamePane);
				Punch.setDisable(false);
				Settings.setDisable(false);
				EndTurn.setDisable(false);
				Attack.setDisable(false);
				Cast.setDisable(false);
				Move.setDisable(false);
			}
		});
		if(!isSinglePlayer || p1.equals(game.checkGameOver())) {
			gameOver.Text.setText("CONGRATS " + game.checkGameOver().getName().toUpperCase() + "\nYOU HAVE WON!!!!");
		}
		else {
			gameOver.Text.setText("SORRY " + p1.getName().toUpperCase() + "\nYOU LOST!!!!" + "\nBETTER LUCK NEXT TIME :)");
		}
		
		GamePane.getChildren().add(gameOver);
		Punch.setDisable(true);
		Settings.setDisable(true);
		EndTurn.setDisable(true);
		Attack.setDisable(true);
		Cast.setDisable(true);
		Move.setDisable(true);
		gameOver.setOpacity(0);
		FadeIn(gameOver);
	}
	
	public void moveHelper(model.world.Direction d) {
		try {
			game.move(d);
			game.UpdateGrid(grid.Grid, Hover, grid.health);
			if(isFirstPlayer)
				player1.Update(game.getCurrentChampion(), p1);
			else
				player2.Update(game.getCurrentChampion(), p2);
		}
		catch(UnallowedMovementException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);

		}
		catch(NotEnoughResourcesException u) {
			ExceptionPane b = new ExceptionPane(u.getMessage().toUpperCase());
			GamePane.getChildren().add(b);
			Hover.setText("");
			game.UpdateGrid(grid.Grid, Hover, grid.health);

		}
	}
	
	public void switchToSettings() {
		settingsPane = new SettingsPane();
		if(MenuClip.isRunning()) {
			settingsPane.on.setSelected(true);
			settingsPane.off.setSelected(false);
		}
		else {
			settingsPane.off.setSelected(true);
			settingsPane.on.setSelected(false);
		}
		settingsPane.off.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				MusicOff2(settingsPane);
			}
		});
		settingsPane.on.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				MusicOn2(settingsPane);
			}
		});
		settingsPane.Return.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isSettings = true;
				FadeOut(settingsPane);
				Punch.setDisable(false);
				Settings.setDisable(false);
				EndTurn.setDisable(false);
				Attack.setDisable(false);
				Cast.setDisable(false);
				Move.setDisable(false);
			}
		});
		settingsPane.MainMenu.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isGamePane = true;
				FadeOut(GamePane);
				p1 = null;
				p2 = null;
			}
		});
		Punch.setDisable(true);
		Settings.setDisable(true);
		EndTurn.setDisable(true);
		Attack.setDisable(true);
		Cast.setDisable(true);
		Move.setDisable(true);
		GamePane.getChildren().add(settingsPane);
		settingsPane.setOpacity(0);
		FadeIn(settingsPane);
	}
	
	public void MusicOn2(SettingsPane a) {
		settingsPane.on.setSelected(true);
		settingsPane.off.setSelected(false);
		MenuClip.start();
		MenuClip.loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	public void MusicOff2(SettingsPane a) {
		settingsPane.off.setSelected(true);
		settingsPane.on.setSelected(false);
		MenuClip.stop();
	}
	
	public void switchToMainMenu() {
		MainMenu = new AnchorPane1(1960, 1080);
    	Font.loadFont(getClass().getResourceAsStream("Aviano.otf"), 10);
    	ExitGame = new Button1(370, 89, 795, 712, "EXIT GAME", "center");
    	ExitGame.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isExit = true;
				FadeOut(MainMenu);
			}
		});
    	ToggleMusic = new Label1(269, 30, 700, 836, "TOGGLE MUSIC", "center"); //124
    	SinglePlayer = new Button1(370, 89, 795, 370, "SINGLE PLAYER", "center"); //114
    	SinglePlayer.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isMainMenu = true;
				isSinglePlayer = true;
				FadeOut(MainMenu);
			}
		});
    	MultiPlayer = new Button1(370, 89, 795, 484, "MULTI PLAYER", "center");
    	MultiPlayer.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isMainMenu = true;
				isSinglePlayer = false;
				FadeOut(MainMenu);
			}
		});
    	instructions = new Button1(370, 89, 795, 598, "INSTRUCTIONS", "center");
    	instructions.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				switchToInstructions();
			}
		});
    	Logo = new ImageView1(502, 185, 729, 160, "/images/Logo.png", "center");
    	On = new CheckBox1(36, 37, 1006, 831, "center"); //5
    	On.setStyle("-fx-font-size: 24px;");
    	On.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				MusicOn();
			}
		});
    	Off = new CheckBox1(36, 37, 1144, 831, "center"); //5
    	Off.setStyle("-fx-font-size: 24px;");
    	Off.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				MusicOff();
			}
		});
    	on = new Label1(54, 30, 1053, 836, "ON", "center");
    	off = new Label1(69, 30, 1191, 836, "OFF", "center");
    	MainMenu.getChildren().add(On);
    	MainMenu.getChildren().add(Off);
    	MainMenu.getChildren().add(off);
    	MainMenu.getChildren().add(on);
    	MainMenu.getChildren().add(SinglePlayer);
    	MainMenu.getChildren().add(MultiPlayer);
    	MainMenu.getChildren().add(ExitGame);
    	MainMenu.getChildren().add(instructions);
    	MainMenu.getChildren().add(Logo);
    	MainMenu.getChildren().add(ToggleMusic);
    	SetLayout();
    	Scene = new Scene(MainMenu, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
    	Scene.getStylesheets().add("/images/application.css");
    	Scene.setFill(Color.BLACK);
		stage.setScene(Scene);
		stage.setFullScreen(true);
		stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
		stage.show();
		MainMenu.setOpacity(0);
		FadeIn(MainMenu);
	}
	
	public void switchToInstructions(){
		first = true;
		second = false;
		third = false;
		if(InstructionsPane == null) {
			InstructionsPane = new AnchorPane1(1160, 730, 400, 175, "center");
			InstructionsPane.setLayoutX(400 + (widthh - 1960)/2);
			InstructionsPane.setLayoutY(175 + (heightt - 1080)/2);
			InstructionsPane.setStyle("-fx-background-color: #cfcdcd;"
					+ "-fx-background-radius: 22px;"
					+ "-fx-border-width: 10px;"
					+ "-fx-border-color: BLACK;"
					+ "-fx-border-radius: 22px;"
					);
			ImageView1 Instructions = new ImageView1(1064, 582, 52, 38, "/images/1.png");
			Button1 backk = new Button1(168, 59, 18, 656, "BACK");
			Button1 Next = new Button1(157, 59, 985, 656, "NEXT");
			
			backk.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					isInstructionsPane = true;
					FadeOut(InstructionsPane);
					Next.setVisible(true);
					Instructions.setImage(new Image("/images/1.png"));
				}
			});
			Next.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent event) {
					if(first) {
						first = false;
						second = true;
						Instructions.setImage(new Image("/images/2.png"));
					}
					else {
						if(second) {
							second = false;
							third = true;
							Instructions.setImage(new Image("/images/3.png"));
						}
						else {
							if(third) {
								third = false;
								fourth = true;
								Instructions.setImage(new Image("/images/4.png"));
							}
							else {
								if(fourth) {
									fifth = true;
									fourth = false;
									Instructions.setImage(new Image("/images/5.png"));
								}
								else {
									if(fifth) {
										fifth = false;
										sixth = true;
										Instructions.setImage(new Image("/images/6.png"));
									}
									else {
										if(sixth) {
											seventh = true;
											sixth = false;
											Instructions.setImage(new Image("/images/7.png"));
										}
										else {
											if(seventh) {
												seventh = false;
												Instructions.setImage(new Image("/images/8.png"));
												Next.setVisible(false);
											}
										}
									}
								}
							}
						}
					}
				}
			});
			InstructionsPane.getChildren().add(backk);
			InstructionsPane.getChildren().add(Next);
			InstructionsPane.getChildren().add(Instructions);
			InstructionsPane.setOpacity(0);
			MainMenu.getChildren().add(InstructionsPane);
			FadeIn(InstructionsPane);
		}
		else {
			InstructionsPane.setOpacity(0);
			InstructionsPane.setVisible(true);
			FadeIn(InstructionsPane);
		}
	}
	
	public void SetLayout() {
		if(MenuClip != null) {
			boolean flag;
			flag = MenuClip.isRunning();
			try {
				MenuClip.close();
				File music = new File("music.wav");
				AudioInputStream audioInput = AudioSystem.getAudioInputStream(music);
				MenuClip = AudioSystem.getClip();
				MenuClip.open(audioInput);
				On.setSelected(true);
				}catch(Exception e) {}
			if(flag) {
				MenuClip.start();
				MenuClip.loop(Clip.LOOP_CONTINUOUSLY);
				On.setSelected(true);
				Off.setSelected(false);
			}
			else{
				Off.setSelected(true);
				On.setSelected(false);
			}
		}
		else
			if(MenuClip == null) {
				try {
				File music = new File("music.wav");
				AudioInputStream audioInput = AudioSystem.getAudioInputStream(music);
				MenuClip = AudioSystem.getClip();
				MenuClip.open(audioInput);
				MenuClip.start();
				MenuClip.loop(Clip.LOOP_CONTINUOUSLY);
				On.setSelected(true);
				}catch(Exception e) {}
			}
			else
				if(!MenuClip.isRunning())
					Off.setSelected(true);
		if(Screen.getPrimary().getBounds().getWidth() == 1707.0) {
			MainMenu.setStyle("-fx-background-image: url('images/1707x1067.png');");
		}
		else {
			if(Screen.getPrimary().getBounds().getWidth() == 1536.0)
				MainMenu.setStyle("-fx-background-image: url('images/1536x864.png');");
			else
				MainMenu.setStyle("-fx-background-image: url('images/1960x1080.png');");
		}
	}
	
	public void SetLayout2() {
		if(Screen.getPrimary().getBounds().getWidth() == 1707.0) {
			SelectNames.setStyle("-fx-background-image: url('images/1707x1067Names.png');");
		}
		else {
			if(Screen.getPrimary().getBounds().getWidth() == 1536.0)
				SelectNames.setStyle("-fx-background-image: url('images/1536x864Names.png');");
			else
				SelectNames.setStyle("-fx-background-image: url('images/1960x1080Names.png');");
		}	
	}
	
	public void SetLayout3() {
		if(Screen.getPrimary().getBounds().getWidth() == 1707.0) {
			SelectChampions.setStyle("-fx-background-image: url('images/1707x1067.gif');");
		}
		else {
			if(Screen.getPrimary().getBounds().getWidth() == 1536.0)
				SelectChampions.setStyle("-fx-background-image: url('images/1536x864.gif');");
			else
				SelectChampions.setStyle("-fx-background-image: url('images/1536x864.gif');");
		}
	}
	
	public void SetLayout5() {
		boolean flag;
		flag = MenuClip.isRunning();
		try {
			MenuClip.close();
			File music = new File("GameMusic.wav");
			AudioInputStream audioInput = AudioSystem.getAudioInputStream(music);
			MenuClip = AudioSystem.getClip();
			MenuClip.open(audioInput);
			On.setSelected(true);
			}catch(Exception e) {}
		if(flag) {
			MenuClip.start();
			MenuClip.loop(Clip.LOOP_CONTINUOUSLY);
		}
				
	}

	public void directionalWhite(Ability a) {
		Object[][] board = game.getBoard();
		Champion c = game.getCurrentChampion();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < a.getCastRange(); i++) {
			x++;
			if(x >= 0 && x < 5) {
				if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
					continue;
				}
				if(board[x][y] == null)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/White.png')");
				else {
					if(board[x][y] instanceof Champion && (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF))) {
						Champion c2 = (Champion) board[x][y];
						if((p1.getTeam().contains(game.getCurrentChampion()) && p1.getTeam().contains(c2))) {
							switch(((Champion) board[x][y]).getName()) {
							case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
							case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
							case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
							case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
							case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
							case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
							case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
							case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
							case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
							case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
							case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
							case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
							case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
							case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
							case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
							}
						}
					}
					else {
						if(board[x][y] instanceof Champion && (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF))) {
							Champion c2 = (Champion) board[x][y];
							if(((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion())))) {
								switch(((Champion) board[x][y]).getName()) {
								case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
								case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
								case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
								case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
								case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
								case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
								case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
								case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
								case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
								case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
								case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
								case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
								case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
								case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
								case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
								}
							}
						}
					}
				}
			}
		}
		x = c.getLocation().x;
		for(int i = 0; i < a.getCastRange(); i++) {
			x--;
			if(x >= 0 && x < 5) {
				if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
					continue;
				}
				if(board[x][y] == null)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/White.png')");
				else {
					if(board[x][y] instanceof Champion) {
						Champion c2 = (Champion) board[x][y];
						if((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion()))) {
							switch(((Champion) board[x][y]).getName()) {
							case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
							case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
							case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
							case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
							case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
							case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
							case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
							case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
							case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
							case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
							case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
							case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
							case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
							case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
							case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
							}
						}
					}
				}
			}
		}
		x = c.getLocation().x;
		for(int i = 0; i < a.getCastRange(); i++) {
			y++;
			if(y >= 0 && y < 5) {
				if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
					continue;
				}
				if(board[x][y] == null)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/White.png')");
				else {
					if(board[x][y] instanceof Champion) {
						Champion c2 = (Champion) board[x][y];
						if((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion()))) {
							switch(((Champion) board[x][y]).getName()) {
							case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
							case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
							case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
							case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
							case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
							case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
							case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
							case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
							case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
							case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
							case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
							case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
							case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
							case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
							case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
							}
						}
					}
				}
			}
		}
		y = c.getLocation().y;
		for(int i = 0; i < a.getCastRange(); i++) {
			y--;
			if(y >= 0 && y < 5) {
				if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
					continue;
				}
				if(board[x][y] == null)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/White.png')");
				else {
					if(board[x][y] instanceof Champion) {
						Champion c2 = (Champion) board[x][y];
						if((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion()))) {
							switch(((Champion) board[x][y]).getName()) {
							case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
							case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
							case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
							case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
							case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
							case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
							case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
							case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
							case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
							case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
							case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
							case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
							case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
							case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
							case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
							}
						}
					}
				}
			}
		}
	}
	
	public void singleWhite(Ability a) {
		Object[][] board = game.getBoard();
		int x = game.getCurrentChampion().getLocation().x;
		int y = game.getCurrentChampion().getLocation().y;
		for(int i = 0; i < 5; i++) {
			for(int j = 0; j < 5; j++) {
				if(board[i][j] != null && board[i][j] instanceof Cover && a instanceof DamagingAbility && distance(x, y, i, j) <= a.getCastRange()) {
					grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
					continue;
				}
				if(board[i][j] instanceof Champion && (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF))) {
					Champion c2 = (Champion) board[i][j];
					if((p1.getTeam().contains(game.getCurrentChampion()) && p1.getTeam().contains(c2)) && distance(i, j, x, y) <= a.getCastRange()) {
						switch(((Champion) board[i][j]).getName()) {
						case "Captain America": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
						case "Deadpool": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
						case "Dr Strange": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
						case "Electro": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
						case "Ghost Rider": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
						case "Hela": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
						case "Hulk": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
						case "Iceman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
						case "Ironman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
						case "Loki": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
						case "Quicksilver": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
						case "Spiderman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
						case "Thor": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
						case "Venom": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
						case "Yellow Jacket": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
						}
					}
				}
				else {
					if(board[i][j] instanceof Champion && (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF))) {
						Champion c2 = (Champion) board[i][j];
						if(((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion()))) && distance(i, j, x, y) <= a.getCastRange()) {
							switch(((Champion) board[i][j]).getName()) {
							case "Captain America": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
							case "Deadpool": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
							case "Dr Strange": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
							case "Electro": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
							case "Ghost Rider": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
							case "Hela": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
							case "Hulk": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
							case "Iceman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
							case "Ironman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
							case "Loki": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
							case "Quicksilver": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
							case "Spiderman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
							case "Thor": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
							case "Venom": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
							case "Yellow Jacket": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
							}
						}
					}
				}
			}
		}
	}

	public void selfWhite(Ability a) {
		int i = game.getCurrentChampion().getLocation().x;
		int j = game.getCurrentChampion().getLocation().y;
		switch(game.getCurrentChampion().getName()) {
		case "Captain America": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
		case "Deadpool": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
		case "Dr Strange": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
		case "Electro": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
		case "Ghost Rider": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
		case "Hela": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
		case "Hulk": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
		case "Iceman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
		case "Ironman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
		case "Loki": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
		case "Quicksilver": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
		case "Spiderman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
		case "Thor": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
		case "Venom": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
		case "Yellow Jacket": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
		}
	}

	public void teamWhite(Ability a) {
		ArrayList<Champion> team = null;
		if (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility) a).getEffect().getType() == EffectType.DEBUFF)) {
			if (p1.getTeam().contains(game.getCurrentChampion()))
				team = p2.getTeam();
			else
				team = p1.getTeam();
			} 
		else 
			if (a instanceof HealingAbility || (a instanceof CrowdControlAbility && (a instanceof CrowdControlAbility && ((CrowdControlAbility) a).getEffect().getType() == EffectType.BUFF))) {
				if (p1.getTeam().contains(game.getCurrentChampion()))
					team = p1.getTeam();
				else
					team = p2.getTeam();
			}
		for (Champion c : team) {
			int x = (int) c.getLocation().getX();
			int y = (int) c.getLocation().getY();
			int distance = Math.abs((int) game.getCurrentChampion().getLocation().getX() - x) + Math.abs((int) game.getCurrentChampion().getLocation().getY() - y);
			if (distance <= a.getCastRange()) {
				int i = c.getLocation().x;
				int j = c.getLocation().y;
				switch(c.getName()) {
				case "Captain America": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
				case "Deadpool": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
				case "Dr Strange": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
				case "Electro": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
				case "Ghost Rider": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
				case "Hela": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
				case "Hulk": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
				case "Iceman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
				case "Ironman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
				case "Loki": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
				case "Quicksilver": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
				case "Spiderman": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
				case "Thor": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
				case "Venom": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
				case "Yellow Jacket": grid.Grid[i][j].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
				}
			}
				
		}
	}

	public void surroundWhite(Ability a) {
		Champion c = game.getCurrentChampion();
		Object[][] board = game.getBoard();
		Point Location = c.getLocation(), p = new Point(0,0);
		int x = Location.x - 1;
		int y = Location.y - 1;
		for(int i = 0; i < 3; i++) {
			if(x >=0 && x < 5) {
				y = Location.y - 1;
				for(int j = 0; j < 3; j++) {
					if(y >= 0 && y < 5) {
						p.x = x;
						p.y = y;
						if(board[x][y] != null && board[x][y] instanceof Cover && a instanceof DamagingAbility) {
							grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
							++y;
							continue;
						}
						if(board[x][y] != null && !p.equals(Location)){
							if(board[x][y] instanceof Champion && (a instanceof HealingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.BUFF))) {
								Champion c2 = (Champion) board[x][y];
								if((p1.getTeam().contains(game.getCurrentChampion()) && p1.getTeam().contains(c2))) {
									switch(((Champion) board[x][y]).getName()) {
									case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
									case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
									case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
									case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
									case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
									case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
									case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
									case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
									case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
									case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
									case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
									case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
									case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
									case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
									case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
									}
								}
							}
							else {
								if(board[x][y] instanceof Champion && (a instanceof DamagingAbility || (a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType() == EffectType.DEBUFF))) {
									Champion c2 = (Champion) board[x][y];
									if(((p1.getTeam().contains(game.getCurrentChampion()) && p2.getTeam().contains(c2)) || (p1.getTeam().contains(c2) && p2.getTeam().contains(game.getCurrentChampion())))) {
										switch(((Champion) board[x][y]).getName()) {
										case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
										case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
										case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
										case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
										case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
										case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
										case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
										case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
										case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
										case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
										case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
										case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
										case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
										case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
										case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
										}
									}
								}
							}
						}
						else {
							if(board[x][y] == null) {
								grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/White.png');");
							}
						}
					}
					++y;
				}
			}
			++x;
		}
	}
	
	public void moveWhite() {
		Champion c = game.getCurrentChampion();
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		if(x + 1 < 5 && board[x+1][y] == null)
			grid.Grid[x+1][y].setStyle("-fx-background-image: url('/tiles/White.png');");
		if(y + 1 < 5 && board[x][y + 1] == null)
			grid.Grid[x][y + 1].setStyle("-fx-background-image: url('/tiles/White.png');");
		if(x - 1 >= 0 && board[x-1][y] == null)
			grid.Grid[x-1][y].setStyle("-fx-background-image: url('/tiles/White.png');");
		if(y - 1 >= 0 && board[x][y-1] == null)
			grid.Grid[x][y-1].setStyle("-fx-background-image: url('/tiles/White.png');");
	}
	
	public void attackWhite() {
		Champion c = game.getCurrentChampion();
		Object[][] board = game.getBoard();
		int x = c.getLocation().x;
		int y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			x++;
			if(x >= 0 && x < 5 && board[x][y] != null) {
				if(board[x][y] instanceof Cover)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
				else
					if((p1.getTeam().contains(c) && p2.getTeam().contains((Champion) board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion) board[x][y]))) {
						switch(((Champion) board[x][y]).getName()) {
						case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
						case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
						case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
						case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
						case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
						case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
						case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
						case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
						case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
						case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
						case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
						case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
						case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
						case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
						case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
						}
					}
				break;
			}
		}
		x = c.getLocation().x;
		for(int i = 0; i < c.getAttackRange(); i++) {
			x--;
			if(x >= 0 && x < 5 && board[x][y] != null) {
				if(board[x][y] instanceof Cover)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
				else
					if((p1.getTeam().contains(c) && p2.getTeam().contains((Champion) board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion) board[x][y]))) {
						switch(((Champion) board[x][y]).getName()) {
						case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
						case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
						case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
						case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
						case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
						case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
						case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
						case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
						case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
						case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
						case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
						case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
						case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
						case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
						case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
						}
					}
				break;
			}
		}
		x = c.getLocation().x;
		for(int i = 0; i < c.getAttackRange(); i++) {
			y++;
			if(y >= 0 && y < 5 && board[x][y] != null) {
				if(board[x][y] instanceof Cover)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
				else
					if((p1.getTeam().contains(c) && p2.getTeam().contains((Champion) board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion) board[x][y]))) {
						switch(((Champion) board[x][y]).getName()) {
						case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
						case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
						case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
						case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
						case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
						case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
						case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
						case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
						case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
						case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
						case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
						case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
						case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
						case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
						case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
						}
					}
				break;
			}
		}
		y = c.getLocation().y;
		for(int i = 0; i < c.getAttackRange(); i++) {
			y--;
			if(y >= 0 && y < 5 && board[x][y] != null) {
				if(board[x][y] instanceof Cover)
					grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CoverWhite.png')");
				else
					if((p1.getTeam().contains(c) && p2.getTeam().contains((Champion) board[x][y])) || (p2.getTeam().contains(c) && p1.getTeam().contains((Champion) board[x][y]))) {
						switch(((Champion) board[x][y]).getName()) {
						case "Captain America": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/CaptainAmericaWhite.png');");break;
						case "Deadpool": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DeadpoolWhite.png');");break;
						case "Dr Strange": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/DrStrangeWhite.png');");break;
						case "Electro": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ElectroWhite.png');");break;
						case "Ghost Rider": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/GhostRiderWhite.png');");break;
						case "Hela": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HelaWhite.png');");break;
						case "Hulk": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/HulkWhite.png');");break;
						case "Iceman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IcemanWhite.png');");break;
						case "Ironman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/IronmanWhite.png');");break;
						case "Loki": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/LokiWhite.png');");break;
						case "Quicksilver": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/QuicksilverWhite.png');");break;
						case "Spiderman": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/SpidermanWhite.png');");break;
						case "Thor": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/ThorWhite.png');");break;
						case "Venom": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/VenomWhite.png');");break;
						case "Yellow Jacket": grid.Grid[x][y].setStyle("-fx-background-image: url('/tiles/YellowJacketWhite.png');");break;
						}
					}
				break;
			}
		}
	}
	
	public int distance(int x1, int y1, int x2, int y2) {
		return Math.abs(x1 - x2) + Math.abs(y1 - y2);
	}
	
	public void SetLayout4() {
		if(Screen.getPrimary().getBounds().getWidth() == 1707.0) {
			SelectLeader.setStyle("-fx-background-image: url('images/1707x1067Leader.png');");
		}
		else {
			if(Screen.getPrimary().getBounds().getWidth() == 1536.0)
				SelectLeader.setStyle("-fx-background-image: url('images/1536x864Leader.png');");
			else
				SelectLeader.setStyle("-fx-background-image: url('images/1960x1080Leader.png');");
		}
	}
	
	public void MusicOn() {
		On.setSelected(true);
		Off.setSelected(false);
		MenuClip.start();
		MenuClip.loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	public void MusicOff() {
		Off.setSelected(true);
		On.setSelected(false);
		MenuClip.stop();
	}
	
	public void switchToSelectNames() {
		SelectNames = new AnchorPane1(1960, 1080);
		Player1 = new TextField1(631, 77, 786.5, 436.5, "center");
		Player2 = new TextField1(631, 77, 786.5, 621, "center");
		ChooseName = new Label1(490, 69, 857, 277, "CHOOSE YOUR NAMES", "center");
		Pl1 = new Label1(216, 69, 994, 355, "PLAYER 1:", "center");
		Pl2 = new Label1(232, 69, 986, 541, "PLAYER 2:", "center");
		Next = new Button1(157, 59, 1782, 999, "NEXT", "right");
		Next.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if((isSinglePlayer && Player1.getText().equals("")) || (!isSinglePlayer && (Player1.getText().equals("") || Player2.getText().equals("")))) {
					ExceptionPane a = new ExceptionPane("WRITE YOUR NAMES");
					SelectNames.getChildren().add(a);
				}
				else {
					p1 = new Player(Player1.getText());
					if(isSinglePlayer)
						p2 = new Player("COMPUTER");
					else
						p2 = new Player(Player2.getText());
					isSelectNames = true;
					FadeOut(SelectNames);
				}
			}
		});
		Back = new Button1(168, 59, 21, 999, "BACK", "left");
		Back.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				isSelectNames = true;
				isMainMenu = true;
				FadeOut(SelectNames);
			}
		});
		SelectNames.getChildren().add(Next);
		SelectNames.getChildren().add(Back);
		SelectNames.getChildren().add(Pl1);
		SelectNames.getChildren().add(Pl2);
		SelectNames.getChildren().add(Player1);
		SelectNames.getChildren().add(Player2);
		SelectNames.getChildren().add(ChooseName);
		SetLayout2();
		SelectNames.setOnKeyPressed(event -> {
			if(event.getCode()!=KeyCode.ENTER){
            	Player1.requestFocus();
			}
        });
		Player1.setOnKeyPressed(event -> {
            if(event.getCode().equals(KeyCode.ENTER)){
            	if(isSinglePlayer)
            		Next.fire();
            	else
            		Player2.requestFocus();
            }
        });
		Player2.setOnKeyPressed(event -> {
            if(event.getCode().equals(KeyCode.ENTER)){
            	Next.fire();
            }
        });
		if(isSinglePlayer) {
			Pl2.setVisible(false);
			Pl2 .setDisable(true);
			Player2.setDisable(true);
			Player2.setVisible(false);
		}
		Scene = new Scene(SelectNames, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
		Scene.getStylesheets().add("/images/application.css");
		Scene.setFill(Color.BLACK);
    	stage.setScene(Scene);
		stage.setFullScreen(true);
		stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
		stage.show();
		SelectNames.setOpacity(0);
		FadeIn(SelectNames);
	}

	public void FadeIn(Node n) {
		FadeTransition t = new FadeTransition();
		t.setDuration(Duration.millis(500));
		t.setNode(n);
		t.setFromValue(0);
		t.setToValue(1);
		t.play();
	}
	
	public void FadeIn2(Node n) {
		FadeTransition t = new FadeTransition();
		t.setDuration(Duration.millis(4000));
		t.setNode(n);
		t.setFromValue(0);
		t.setToValue(1);
		t.setOnFinished(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				SetLayout3();
			}
		});
		t.play();
	}
	
	public void FadeOut(Node n) {
		FadeTransition t = new FadeTransition();
		t.setDuration(Duration.millis(1000));
		t.setNode(n);
		t.setFromValue(1);
		t.setToValue(0);
		t.setOnFinished(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				if(isSelectNames && isMainMenu) {
					switchToMainMenu();
					isMainMenu = false;
					isSelectNames = false;
				}
				else {
					if(isMainMenu) {
						switchToSelectNames();
						isMainMenu = false;
					}
					else {
						if(isExit) {
							System.exit(0);
						}
						else {
							if(isSelectNames) {
								switchToChooseChampions();
								isSelectNames = false;
							}
							else {
								if(isSelectChampion) {
									switchToSelectLeader();
									isSelectChampion = false;
								}
								else {
									if(isInstructionsPane) {
										isInstructionsPane = false;
										InstructionsPane.setVisible(false);
									}
									else {
										if(isSelectLeader) {
											switchToGamePane();
											isSelectLeader = false;
										}
										else {
											if(isGamePane) {
												isGamePane = false;
												switchToMainMenu();
											}
											else {
												if(isSettings) {
													isSettings = false;
													settingsPane.setVisible(false);
												}
											}
										}
									}
								}
							}
						}
					}
				}
				
			}
		});
		t.play();
	}

	public void switchToChooseChampions() {
		try {
			Game.loadAbilities("Abilities.csv");
			Game.loadChampions("Champions.csv");
		} catch (IOException e) {}
		SelectChampions = new AnchorPane1(2, 3);
//		if(Screen.getPrimary().getBounds().getWidth() == 1707)
			SelectChampions.setStyle("-fx-background-image: url('images/1707x1067Intro.gif');");
//		else
//			SelectChampions.setStyle("-fx-background-image: url('images/1536x864Intro.gif');");
		ImageView2 g = new ImageView2();
		g.setVisible(false);
		ImageView1 k = new ImageView1(200, 100, 0, 980, "/championInfo/Info.png", "left");
		String r = p1.getName().toUpperCase() + " SELECT YOUR 1ST CHAMPION";
		borderGlow = new BorderGlow();
		redBorderGlow = new RedBorderGlow();
		blueBorderGlow = new BlueBorderGlow();
		captainAmerica = new CaptainAmerica();
		doctorStrange = new DoctorStrange();
		electro = new Electro();  
		ghostRider = new GhostRider(); 
		hela = new Hela(); 
		hulk = new Hulk();
	    iceman = new Iceman();
	    ironman = new Ironman();
	    loki = new Loki();
	    quickSilver = new QuickSilver();
	    spiderman = new Spiderman();
	    thor = new Thor();
	    venom = new Venom();
	    yellowJacket = new YellowJacket();
	    next = new Next();
		deadPool = new DeadPool(); 
		choose = new Label1(Screen.getPrimary().getBounds().getWidth(), 30, 0, iceman.getLayoutY()/2 , r, "above");
		choose.setAlignment(Pos.CENTER);
		champions = new ArrayList<ToggleButton>();
	    champions.add(captainAmerica);
	    champions.add(deadPool);
	    champions.add(doctorStrange);
	    champions.add(electro);
	    champions.add(ghostRider);
	    champions.add(hela);
	    champions.add(hulk);
	    champions.add(iceman);
	    champions.add(ironman);
	    champions.add(loki);
	    champions.add(quickSilver);
	    champions.add(spiderman);
	    champions.add(thor);
	    champions.add(venom);
	    champions.add(yellowJacket);
		captainAmerica.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		captainAmerica.setSelected(true);
	    		captainAmerica.setEffect(borderGlow);
	    	}});
		captainAmerica.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/CaptainAmericaInfo.png"));
	    		g.setVisible(true);
	    	}});
		captainAmerica.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		deadPool.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		deadPool.setSelected(true);
	    		deadPool.setEffect(borderGlow);
	    	}});
		deadPool.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/DeadpoolInfo.png"));
	    		g.setVisible(true);
	    	}});
		deadPool.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		doctorStrange.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		doctorStrange.setSelected(true);
	    		doctorStrange.setEffect(borderGlow);
	    	}});
		doctorStrange.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/DrStrangeInfo.png"));
	    		g.setVisible(true);
	    	}});
		doctorStrange.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		electro.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		electro.setSelected(true);
	    		electro.setEffect(borderGlow);
	    	}});
		electro.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/ElectroInfo.png"));
	    		g.setVisible(true);
	    	}});
		electro.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		ghostRider.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		ghostRider.setSelected(true);
	    		ghostRider.setEffect(borderGlow);
	    	}});
		ghostRider.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/GhostRiderInfo.png"));
	    		g.setVisible(true);
	    	}});
		ghostRider.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		hela.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		hela.setSelected(true);
	    		hela.setEffect(borderGlow);
	    	}});
		hela.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/HelaInfo.png"));
	    		g.setVisible(true);
	    	}});
		hela.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
		hulk.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		hulk.setSelected(true);
	    		hulk.setEffect(borderGlow);
	    	}});
		hulk.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/HulkInfo.png"));
	    		g.setVisible(true);
	    	}});
		hulk.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    iceman.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		iceman.setSelected(true);
	    		iceman.setEffect(borderGlow);
	    	}});
	    iceman.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/IcemanInfo.png"));
	    		g.setVisible(true);
	    	}});
	    iceman.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    ironman.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		ironman.setSelected(true);
	    		ironman.setEffect(borderGlow);
	    	}});
	    ironman.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/IronmanInfo.png"));
	    		g.setVisible(true);
	    	}});
	    ironman.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    loki.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		loki.setSelected(true);
	    		loki.setEffect(borderGlow);
	    	}});
	    loki.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/LokiInfo.png"));
	    		g.setVisible(true);
	    	}});
	    loki.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    quickSilver.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		quickSilver.setSelected(true);
	    		quickSilver.setEffect(borderGlow);
	    	}});
	    quickSilver.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/QuicksilverInfo.png"));
	    		g.setVisible(true);
	    	}});
	    quickSilver.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    spiderman.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		spiderman.setSelected(true);
	    		spiderman.setEffect(borderGlow);
	    	}});
	    spiderman.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/SpidermanInfo.png"));
	    		g.setVisible(true);
	    	}});
	    spiderman.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    thor.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		thor.setSelected(true);
	    		thor.setEffect(borderGlow);
	    	}});
	    thor.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/ThorInfo.png"));
	    		g.setVisible(true);
	    	}});
	    thor.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    venom.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		venom.setSelected(true);
	    		venom.setEffect(borderGlow);
	    	}});
	    venom.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/VenomInfo.png"));
	    		g.setVisible(true);
	    	}});
	    venom.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    yellowJacket.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		setNotSlelected(champions);
	    		yellowJacket.setSelected(true);
	    		yellowJacket.setEffect(borderGlow);
	    	}});
	    yellowJacket.setOnMouseEntered(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setImage(new Image("/championInfo/YellowJacketInfo.png"));
	    		g.setVisible(true);
	    	}});
	    yellowJacket.setOnMouseExited(new EventHandler<MouseEvent>() {
	    	@Override
	    	public void handle(MouseEvent event) {
	    		g.setVisible(false);
	    	}});
	    next.setOnAction(new EventHandler<ActionEvent>() {
	    	@Override
	    	public void handle(ActionEvent event) {
	    		if(!checkSelected()) {
	    			ExceptionPane a = new ExceptionPane("PLEASE SELECT A CHAMPION");
					SelectChampions.getChildren().add(a);
				}
	    		else {
	    			setToggle();
	    		}
	    	}});
	    captainAmerica.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    deadPool.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    doctorStrange.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    electro.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    ghostRider.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    hela.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    hulk.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    iceman.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    ironman.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    loki.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    quickSilver.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    spiderman.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    thor.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    venom.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });
	    yellowJacket.setOnKeyPressed(e -> {
	        if (e.getCode().equals(KeyCode.ENTER)) {
	           next.fire(); 
	        }
	    });		
	    SelectChampions.getChildren().add(g);
	    SelectChampions.getChildren().add(k);
	    addChildren(SelectChampions);
	    SelectChampions.getChildren().add(choose);
	    Scene = new Scene(SelectChampions, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
		Scene.getStylesheets().add("/images/application2.css");
		Scene.setFill(Color.rgb(0, 0, 0));
    	stage.setScene(Scene);
		stage.setFullScreen(true);
		stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
		stage.show();
		SelectChampions.setOpacity(0);
		g.setOpacity(0);
		k.setOpacity(0);
		venom.setOpacity(0);
		thor.setOpacity(0);
		spiderman.setOpacity(0);
		quickSilver.setOpacity(0);
		loki.setOpacity(0);
		ironman.setOpacity(0);
		iceman.setOpacity(0);
		hulk.setOpacity(0);
		hela.setOpacity(0);
		ghostRider.setOpacity(0);
		electro.setOpacity(0);
		doctorStrange.setOpacity(0);
		deadPool.setOpacity(0);
		captainAmerica.setOpacity(0);
		next.setOpacity(0);
		yellowJacket.setOpacity(0);
		FadeIn(SelectChampions);
	    FadeIn2(yellowJacket);
	    FadeIn2(next);
	    FadeIn2(captainAmerica);
	    FadeIn2(deadPool);
	    FadeIn2(doctorStrange);
	    FadeIn2(electro);
	    FadeIn2(ghostRider);
	    FadeIn2(hela);
	    FadeIn2(hulk);
	    FadeIn2(iceman);
	    FadeIn2(ironman);
	    FadeIn2(loki);
	    FadeIn2(quickSilver);
	    FadeIn2(spiderman);
	    FadeIn2(thor);
	    FadeIn2(venom);
	    FadeIn2(g);
	    FadeIn2(k);
	}
	
	public void setNotSlelected(ArrayList<ToggleButton> arr) {
		for(ToggleButton t : arr) {
			if(!t.isDisabled()) {
			t.setSelected(false);
			t.setEffect(null);
			}
		}
	}
	
	public void addChildren(AnchorPane1 x) {
		for(ToggleButton t : champions)
			x.getChildren().add(t);
		x.getChildren().add(next);
	}
	
	public void setToggle() {
		if(!isSinglePlayer) {
			String r = "";
			for(ToggleButton t : champions) {
				if(t.isSelected()) {
					if(togglesNo%2 == 0) {
						t.setEffect(redBorderGlow);
						switch(whichChampion) {
						case 1: r = p2.getName().toUpperCase() + " CHOOSE YOUR 1ST CHAMPION";break;
						case 2: r = p2.getName().toUpperCase() + " CHOOSE YOUR 2ND CHAMPION";break;
						case 3: r = p2.getName().toUpperCase() + " CHOOSE YOUR 3RD CHAMPION";break;
						}	
					}
					if(togglesNo%2 == 1) {
						t.setEffect(blueBorderGlow);
						whichChampion++;
						switch(whichChampion) {
						case 1: r = p1.getName().toUpperCase() + " CHOOSE YOUR 1ST CHAMPION";break;
						case 2: r = p1.getName().toUpperCase() + " CHOOSE YOUR 2ND CHAMPION";break;
						case 3: r = p1.getName().toUpperCase() + " CHOOSE YOUR 3RD CHAMPION";break;
						}
					}
					t.setSelected(false);
					t.setDisable(true);
					playersChampions.add(getChampion(t));
					choose.setText(r);
					break;
				}
			}
			togglesNo++;
		}
		else {
			if(togglesNo%2 == 0) {
				for(ToggleButton t : champions) {
					if(t.isSelected()) {
						t.setEffect(redBorderGlow);
						t.setSelected(false);
						t.setDisable(true);
						playersChampions.add(getChampion(t));
						togglesNo++;
						String r = "";
						whichChampion++;
						switch(whichChampion) {
						case 1: r = p1.getName().toUpperCase() + " CHOOSE YOUR 1ST CHAMPION";break;
						case 2: r = p1.getName().toUpperCase() + " CHOOSE YOUR 2ND CHAMPION";break;
						case 3: r = p1.getName().toUpperCase() + " CHOOSE YOUR 3RD CHAMPION";break;
						}
						choose.setText(r);
						break;
					}	
				}
				if(!hulk.isDisable()) {
					hulk.setEffect(blueBorderGlow);
					hulk.setSelected(false);
					hulk.setDisable(true);
					playersChampions.add(getChampion(hulk));
					togglesNo++;
				}
				else {
					if(!quickSilver.isDisable()) {
						quickSilver.setEffect(blueBorderGlow);
						quickSilver.setSelected(false);
						quickSilver.setDisable(true);
						playersChampions.add(getChampion(quickSilver));
						togglesNo++;
					}
					else {
						if(!ghostRider.isDisable()) {
							ghostRider.setEffect(blueBorderGlow);
							ghostRider.setSelected(false);
							ghostRider.setDisable(true);
							playersChampions.add(getChampion(ghostRider));
							togglesNo++;
						}
						else {
							do {
								ToggleButton t = null;
								int f = (int)(Math.random() * 15);
								switch(f) {
								case 0: if(!captainAmerica.isDisable()) t = captainAmerica;break;
								case 1: if(!deadPool.isDisable()) t = deadPool;break;
								case 2: if(!doctorStrange.isDisable()) t = doctorStrange;break;
								case 3: if(!electro.isDisable()) t = electro;break;
								case 4: if(!ghostRider.isDisable()) t = ghostRider;break;
								case 5: if(!hela.isDisable()) t = hela;break;
								case 6: if(!hulk.isDisable()) t = hulk;break;
								case 7: if(!iceman.isDisable()) t = iceman;break;
								case 8: if(!ironman.isDisable()) t = ironman;break;
								case 9: if(!loki.isDisable()) t = loki;break;
								case 10: if(!spiderman.isDisable()) t = spiderman;break;
								case 11: if(!thor.isDisable()) t = thor;break;
								case 12: if(!venom.isDisable()) t = venom;break;
								case 13: if(!yellowJacket.isDisable()) t = yellowJacket;break;
								case 14: if(!quickSilver.isDisable()) t = quickSilver;break;
								}
								if(t != null) {
									t.setEffect(blueBorderGlow);
									t.setSelected(false);
									t.setDisable(true);
									playersChampions.add(getChampion(t));
									togglesNo++;
									break;
								}
							}while(true);
						}
					}
				}
			}
		}
		if(togglesNo == 6) {
			setTeams();
			isSelectChampion = true;
			FadeOut(SelectChampions);
			togglesNo = 0;
			whichChampion = 1;
			while(!champions.isEmpty())
				champions.remove(0);
			while(!playersChampions.isEmpty())
				playersChampions.remove(0);	
			while(!players1.isEmpty())
				players1.remove(0);	
			while(!players2.isEmpty())
				players2.remove(0);	
		}
		
	}
	
	public void switchToSelectLeader() {
		blackBorderGlow = new BlackBorderGlow();
		SelectLeader = new AnchorPane1(1,2);
		LeaderButton t1 = new LeaderButton(508, 269, p1.getTeam().get(0).getName());
		players1.add(t1);
		t1.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		   	public void handle(ActionEvent event) {
		   		setNotSlelected2(players1);
		    	t1.setSelected(true);
		    	t1.setEffect(blackBorderGlow);
		 }});
		LeaderButton t2 = new LeaderButton(708, 269, p1.getTeam().get(1).getName());
		players1.add(t2);
		t2.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		   	public void handle(ActionEvent event) {
		   		setNotSlelected2(players1);
		    	t2.setSelected(true);
		    	t2.setEffect(blackBorderGlow);
		 }});
		LeaderButton t3 = new LeaderButton(908, 269, p1.getTeam().get(2).getName());
		players1.add(t3);
		t3.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		   	public void handle(ActionEvent event) {
		   		setNotSlelected2(players1);
		    	t3.setSelected(true);
		    	t3.setEffect(blackBorderGlow);
		 }});
		LeaderButton t4 = new LeaderButton(508, 556, p2.getTeam().get(0).getName());
		players2.add(t4);
		t4.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent event) {
		    	setNotSlelected2(players2);
		    	t4.setSelected(true);
		    	t4.setEffect(blackBorderGlow);
		    }});
		LeaderButton t5 = new LeaderButton(708, 556, p2.getTeam().get(1).getName());
		players2.add(t5);
		t5.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent event) {
		    	setNotSlelected2(players2);
		    	t5.setSelected(true);
		    	t5.setEffect(blackBorderGlow);
		    }});
		LeaderButton t6 = new LeaderButton(908, 556, p2.getTeam().get(2).getName());
		players2.add(t6);
		t6.setOnAction(new EventHandler<ActionEvent>() {
		    @Override
		    public void handle(ActionEvent event) {
		    	setNotSlelected2(players2);
		    	t6.setSelected(true);
		    	t6.setEffect(blackBorderGlow);
		    }});
		Button1 Next = new Button1(157, 59, 1782, 999, "NEXT", "right");
		Next.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if(!isLeadersSelected()) {
					ExceptionPane a = new ExceptionPane("SELECT YOUR LEADERS");
					Button1 y = new Button1(109, 59, 558, 190, "OK");
					y.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							a.setVisible(false);
						}
					});
					a.getChildren().add(y);
					SelectLeader.getChildren().add(a);
				}
				else {
					setLeaders();
					isSelectLeader = true;
					FadeOut(SelectLeader);
				}
			}
		});
		String r1 = p1.getName().toUpperCase() + " SELECT YOUR LEADER";
		String r2 = p2.getName().toUpperCase() + " SELECT YOUR LEADER";
		Label1 a = new Label1(Screen.getPrimary().getBounds().getWidth(), 69, 0, 173 + (Screen.getPrimary().getBounds().getHeight() - 864)/2, r1, "above");
		Label1 b = new Label1(Screen.getPrimary().getBounds().getWidth(), 69, 0, 460 + (Screen.getPrimary().getBounds().getHeight() - 864)/2, r2, "above");
		SelectLeader.getChildren().add(a);
		SelectLeader.getChildren().add(b);
		SelectLeader.getChildren().add(Next);
		SelectLeader.getChildren().add(t1);
		SelectLeader.getChildren().add(t2);
		SelectLeader.getChildren().add(t3);
		SelectLeader.getChildren().add(t4);
		SelectLeader.getChildren().add(t5);
		SelectLeader.getChildren().add(t6);
		SetLayout4();
		if(isSinglePlayer) {
			t4.setVisible(false);
			t5.setVisible(false);
			t6.setVisible(false);
			t4.setDisable(true);
			t5.setDisable(true);
			t6.setDisable(true);
			b.setVisible(false);
		}
		Scene = new Scene(SelectLeader, Screen.getPrimary().getBounds().getWidth(), Screen.getPrimary().getBounds().getHeight());
		Scene.getStylesheets().add("/images/application.css");
		Scene.setFill(Color.BLACK);
    	stage.setScene(Scene);
		stage.setFullScreen(true);
		stage.show();
		SelectLeader.setOpacity(0);
		FadeIn(SelectLeader);
	}
	
	protected void setNotSlelected2(ArrayList<LeaderButton> arr) {
		for(LeaderButton t : arr) {
			if(!t.isDisabled()) {
			t.setSelected(false);
			t.setEffect(null);
			}
		}
	}

	public void setLeaders() {
		for(LeaderButton t : players1) {
			if(t.isSelected())
				p1.setLeader(p1.getTeam().get(FindChampion(t.name)));
		}
		if(isSinglePlayer) {
			int i = (int)(Math.random() * 3);
			p2.setLeader(p2.getTeam().get(i));
		}
		else {
			for(LeaderButton t : players2) {
				if(t.isSelected())
					p2.setLeader(p2.getTeam().get(FindChampion(t.name)));
			}
		}
	}
	
	public int FindChampion(String s) {
		for(int i = 0; i < p1.getTeam().size(); i++)
			if(p1.getTeam().get(i).getName().equals(s))
				return i;
		for(int i = 0; i < p2.getTeam().size(); i++)
			if(p2.getTeam().get(i).getName().equals(s))
				return i;
		return -1;
	}

	public boolean isLeadersSelected() {
		int i = 0;
		for(ToggleButton t : players1)
			if(t.isSelected())
				i++;
		if(!isSinglePlayer) {
			for(ToggleButton t : players2)
				if(t.isSelected())
					i++;
		}
		else
			i++;
		if(i == 2)
			return true;
		return false;
	}
	
	public void setTeams() {
		for(int i = 0; i < playersChampions.size(); i++) {
			if(i%2 == 0)
				p1.getTeam().add(playersChampions.get(i));
			else
				p2.getTeam().add(playersChampions.get(i));
		}
	}

	public Champion getChampion(ToggleButton t) {
		if(t instanceof CaptainAmerica)
			return Game.getAvailableChampions().get(0);
		if(t instanceof DeadPool)
			return Game.getAvailableChampions().get(1);
		if(t instanceof DoctorStrange)
			return Game.getAvailableChampions().get(2);
		if(t instanceof Electro)
			return Game.getAvailableChampions().get(3);
		if(t instanceof GhostRider)
			return Game.getAvailableChampions().get(4);
		if(t instanceof Hela)
			return Game.getAvailableChampions().get(5);
		if(t instanceof Hulk)
			return Game.getAvailableChampions().get(6);
		if(t instanceof Iceman)
			return Game.getAvailableChampions().get(7);
		if(t instanceof Ironman)
			return Game.getAvailableChampions().get(8);
		if(t instanceof Loki)
			return Game.getAvailableChampions().get(9);
		if(t instanceof QuickSilver)
			return Game.getAvailableChampions().get(10);
		if(t instanceof Spiderman)
			return Game.getAvailableChampions().get(11);
		if(t instanceof Thor)
			return Game.getAvailableChampions().get(12);
		if(t instanceof Venom)
			return Game.getAvailableChampions().get(13);
		if(t instanceof YellowJacket)
			return Game.getAvailableChampions().get(14);
		return null;
	}
	
	public boolean checkSelected() {
		for(ToggleButton t : champions) {
			if(t.isSelected()) {
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
