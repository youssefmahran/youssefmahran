package model.world;

import java.util.ArrayList;

import controls.GridCell;
import controls.GridPane1;
import javafx.scene.layout.GridPane;

public class Villain extends Champion {

	public Villain(String name, int maxHP, int maxMana, int actions, int speed, int attackRange, int attackDamage) {
		super(name, maxHP, maxMana, actions, speed, attackRange, attackDamage, "VILLAIN");

	}

	@Override
	public void useLeaderAbility(ArrayList<Champion> targets, GridCell[][] arr, GridPane1 grid) {
		for (Champion c : targets) {

			c.setCurrentHP(0);
			GridCell temp = new GridCell();
			switch(c.getName()) {
			case "Captain America": temp.setStyle("-fx-background-image: url('/tiles/CaptainAmericaRed.png');");break;
			case "Deadpool": temp.setStyle("-fx-background-image: url('/tiles/DeadpoolRed.png');");break;
			case "Dr Strange": temp.setStyle("-fx-background-image: url('/tiles/DrStrangeRed.png');");break;
			case "Electro": temp.setStyle("-fx-background-image: url('/tiles/ElectroRed.png');");break;
			case "Ghost Rider": temp.setStyle("-fx-background-image: url('/tiles/GhostRiderRed.png');");break;
			case "Hela": temp.setStyle("-fx-background-image: url('/tiles/HelaRed.png');");break;
			case "Hulk": temp.setStyle("-fx-background-image: url('/tiles/HulkRed.png');");break;
			case "Iceman": temp.setStyle("-fx-background-image: url('/tiles/IcemanRed.png');");break;
			case "Ironman": temp.setStyle("-fx-background-image: url('/tiles/IronmanRed.png');");break;
			case "Loki": temp.setStyle("-fx-background-image: url('/tiles/LokiRed.png');");break;
			case "Quicksilver": temp.setStyle("-fx-background-image: url('/tiles/QuicksilverRed.png');");break;
			case "Spiderman": temp.setStyle("-fx-background-image: url('/tiles/SpidermanRed.png');");break;
			case "Thor": temp.setStyle("-fx-background-image: url('/tiles/ThorRed.png');");break;
			case "Venom": temp.setStyle("-fx-background-image: url('/tiles/VenomRed.png');");break;
			case "Yellow Jacket": temp.setStyle("-fx-background-image: url('/tiles/YellowJacketRed.png');");break;
			}
			GridPane.setRowIndex(temp, Math.abs(c.getLocation().x - 4));
			GridPane.setColumnIndex(temp, Math.abs(c.getLocation().y));
			grid.getChildren().add(temp);
			temp.setOpacity(0);
			FadeIn(temp);
		}

	}

}
