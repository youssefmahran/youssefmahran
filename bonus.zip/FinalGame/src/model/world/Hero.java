package model.world;

import java.util.ArrayList;

import controls.GridCell;
import controls.GridPane1;
import javafx.scene.layout.GridPane;
import model.effects.Effect;
import model.effects.EffectType;
import model.effects.Embrace;

public class Hero extends Champion {

	public Hero(String name, int maxHP, int maxMana, int actions, int speed, int attackRange, int attackDamage) {
		super(name, maxHP, maxMana, actions, speed, attackRange, attackDamage, "HERO");

	}

	@Override
	public void useLeaderAbility(ArrayList<Champion> targets, GridCell[][] arr, GridPane1 grid) {
		for (Champion c : targets) {
			int i = 0;
			while (i < c.getAppliedEffects().size()) {
				Effect e = c.getAppliedEffects().get(i);
				if (e.getType() == EffectType.DEBUFF) {
					e.remove(c);
					c.getAppliedEffects().remove(e);

				} else
					i++;
			}
				Embrace em = new Embrace(2);
				
				em.apply(c);
				c.getAppliedEffects().add(em);
				
				GridCell temp = new GridCell();
				switch(c.getName()) {
				case "Captain America": temp.setStyle("-fx-background-image: url('/tiles/CaptainAmericaBlue.png');");break;
				case "Deadpool": temp.setStyle("-fx-background-image: url('/tiles/DeadpoolBlue.png');");break;
				case "Dr Strange": temp.setStyle("-fx-background-image: url('/tiles/DrStrangeBlue.png');");break;
				case "Electro": temp.setStyle("-fx-background-image: url('/tiles/ElectroBlue.png');");break;
				case "Ghost Rider": temp.setStyle("-fx-background-image: url('/tiles/GhostRiderBlue.png');");break;
				case "Hela": temp.setStyle("-fx-background-image: url('/tiles/HelaBlue.png');");break;
				case "Hulk": temp.setStyle("-fx-background-image: url('/tiles/HulkBlue.png');");break;
				case "Iceman": temp.setStyle("-fx-background-image: url('/tiles/IcemanBlue.png');");break;
				case "Ironman": temp.setStyle("-fx-background-image: url('/tiles/IronmanBlue.png');");break;
				case "Loki": temp.setStyle("-fx-background-image: url('/tiles/LokiBlue.png');");break;
				case "Quicksilver": temp.setStyle("-fx-background-image: url('/tiles/QuicksilverBlue.png');");break;
				case "Spiderman": temp.setStyle("-fx-background-image: url('/tiles/SpidermanBlue.png');");break;
				case "Thor": temp.setStyle("-fx-background-image: url('/tiles/ThorBlue.png');");break;
				case "Venom": temp.setStyle("-fx-background-image: url('/tiles/VenomBlue.png');");break;
				case "Yellow Jacket": temp.setStyle("-fx-background-image: url('/tiles/YellowJacketBlue.png');");break;
				}
				GridPane.setRowIndex(temp, Math.abs(c.getLocation().x - 4));
				GridPane.setColumnIndex(temp, Math.abs(c.getLocation().y));
				grid.getChildren().add(temp);
				temp.setOpacity(0);
				FadeIn(temp);
		}
		}

	}

