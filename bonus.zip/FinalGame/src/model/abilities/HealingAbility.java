package model.abilities;

import java.util.ArrayList;

import controls.GridCell;
import controls.GridPane1;
import javafx.scene.layout.GridPane;
import model.world.Champion;
import model.world.Damageable;

public  class HealingAbility extends Ability {
	private int healAmount;

	public HealingAbility(String name,int cost, int baseCoolDown, int castRadius, AreaOfEffect area,int required, int healingAmount) {
		super(name,cost, baseCoolDown, castRadius, area,required, "HEAL");
		this.healAmount = healingAmount;
	}

	public int getHealAmount() {
		return healAmount;
	}

	public void setHealAmount(int healAmount) {
		this.healAmount = healAmount;
	}

	
	@Override
	public void execute(ArrayList<Damageable> targets, GridCell[][] arr, GridPane1 grid) {
		for (Damageable d : targets) {
			d.setCurrentHP(d.getCurrentHP() + healAmount);
			if(d instanceof Champion) {
				GridCell temp = new GridCell();
				switch(((Champion) d).getName()) {
				case "Captain America": temp.setStyle("-fx-background-image: url('/tiles/CaptainAmericaGreen.png');");break;
				case "Deadpool": temp.setStyle("-fx-background-image: url('/tiles/DeadpoolGreen.png');");break;
				case "Dr Strange": temp.setStyle("-fx-background-image: url('/tiles/DrStrangeGreen.png');");break;
				case "Electro": temp.setStyle("-fx-background-image: url('/tiles/ElectroGreen.png');");break;
				case "Ghost Rider": temp.setStyle("-fx-background-image: url('/tiles/GhostRiderGreen.png');");break;
				case "Hela": temp.setStyle("-fx-background-image: url('/tiles/HelaGreen.png');");break;
				case "Hulk": temp.setStyle("-fx-background-image: url('/tiles/HulkGreen.png');");break;
				case "Iceman": temp.setStyle("-fx-background-image: url('/tiles/IcemanGreen.png');");break;
				case "Ironman": temp.setStyle("-fx-background-image: url('/tiles/IronmanGreen.png');");break;
				case "Loki": temp.setStyle("-fx-background-image: url('/tiles/LokiGreen.png');");break;
				case "Quicksilver": temp.setStyle("-fx-background-image: url('/tiles/QuicksilverGreen.png');");break;
				case "Spiderman": temp.setStyle("-fx-background-image: url('/tiles/SpidermanGreen.png');");break;
				case "Thor": temp.setStyle("-fx-background-image: url('/tiles/ThorGreen.png');");break;
				case "Venom": temp.setStyle("-fx-background-image: url('/tiles/VenomGreen.png');");break;
				case "Yellow Jacket": temp.setStyle("-fx-background-image: url('/tiles/YellowJacketGreen.png');");break;
				}
				GridPane.setRowIndex(temp, Math.abs(((Champion) d).getLocation().x - 4));
				GridPane.setColumnIndex(temp, Math.abs(((Champion) d).getLocation().y));
				grid.getChildren().add(temp);
				temp.setOpacity(0);
				FadeIn(temp);
			}
		}
	}
	

}
