package model.abilities;

import java.util.ArrayList;

import controls.GridCell;
import controls.GridPane1;
import javafx.scene.layout.GridPane;
import model.world.Champion;
import model.world.Cover;
import model.world.Damageable;

public class DamagingAbility extends Ability {

	private int damageAmount;

	public DamagingAbility(String name, int cost, int baseCoolDown, int castRadius, AreaOfEffect area, int required,
			int damageAmount) {
		super(name, cost, baseCoolDown, castRadius, area, required, "DMG");
		this.damageAmount = damageAmount;
	}

	public int getDamageAmount() {
		return damageAmount;
	}

	public void setDamageAmount(int damageAmount) {
		this.damageAmount = damageAmount;
	}

	@Override
	public void execute(ArrayList<Damageable> targets, GridCell[][] arr, GridPane1 grid) {
		for (Damageable d : targets) {
			d.setCurrentHP(d.getCurrentHP() - damageAmount);
			if(d instanceof Cover) {
				GridCell temp = new GridCell();
				temp.setStyle("-fx-background-image: url('/tiles/CoverRed.png');");
				GridPane.setRowIndex(temp, Math.abs(((Cover) d).getLocation().x - 4));
				GridPane.setColumnIndex(temp, Math.abs(((Cover) d).getLocation().y));
				grid.getChildren().add(temp);
				temp.setOpacity(0);
				FadeIn(temp);
			}
			if(d instanceof Champion) {
				GridCell temp = new GridCell();
				switch(((Champion) d).getName()) {
				case "Captain America": temp.setStyle("-fx-background-image: url('/tiles/CaptainAmericaRed.png');");break;
				case "Deadpool": temp.setStyle("-fx-background-image: url('/tiles/DeadpoolRed.png');");break;
				case "Dr Strange": temp.setStyle("-fx-background-image: url('/tiles/DrStrangeRed.png');");break;
				case "Electro": temp.setStyle("-fx-background-image: url('/tiles/ElectroRed.png');");break;
				case "Ghost Rider": temp.setStyle("-fx-background-image: url('/tiles/GhostRiderRed.png');");break;
				case "Hela": temp.setStyle("-fx-background-image: url('/tiles/HelaRed.png');");break;
				case "Hulk": temp.setStyle("-fx-background-image: url('/tiles/HulkRed.png');");break;
				case "Iceman": temp.setStyle("-fx-background-image: url('/tiles/IcemanRed.png');");break;
				case "Ironman": temp.setStyle("-fx-background-image: url('/tiles/IronmanRed.png');");break;
				case "Loki": temp.setStyle("-fx-background-image: url('/tiles/LokiRed.png');");break;
				case "Quicksilver": temp.setStyle("-fx-background-image: url('/tiles/QuicksilverRed.png');");break;
				case "Spiderman": temp.setStyle("-fx-background-image: url('/tiles/SpidermanRed.png');");break;
				case "Thor": temp.setStyle("-fx-background-image: url('/tiles/ThorRed.png');");break;
				case "Venom": temp.setStyle("-fx-background-image: url('/tiles/VenomRed.png');");break;
				case "Yellow Jacket": temp.setStyle("-fx-background-image: url('/tiles/YellowJacketRed.png');");break;
				}
				GridPane.setRowIndex(temp, Math.abs(((Champion) d).getLocation().x - 4));
				GridPane.setColumnIndex(temp, Math.abs(((Champion) d).getLocation().y));
				grid.getChildren().add(temp);
				temp.setOpacity(0);
				FadeIn(temp);
			}
		}
	}
}
