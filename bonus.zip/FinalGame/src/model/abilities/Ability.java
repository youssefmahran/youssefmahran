package model.abilities;

import java.util.ArrayList;

import controls.GridCell;
import controls.GridPane1;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.util.Duration;
import model.world.Damageable;

public abstract class Ability {
	private String name;
	private int manaCost;
	private int baseCooldown;
	private int currentCooldown;
	private int castRange;
	private AreaOfEffect castArea;
	private int requiredActionPoints;
	private String Type;

	public Ability(String name, int cost, int baseCoolDown, int castRange, AreaOfEffect area, int required, String Type) {
		this.name = name;
		this.manaCost = cost;
		this.baseCooldown = baseCoolDown;
		this.currentCooldown = 0;
		this.castRange = castRange;
		this.castArea = area;
		this.requiredActionPoints = required;
		this.Type = Type.toUpperCase();
	}

	public int getCurrentCooldown() {
		return currentCooldown;
	}
	public abstract void execute(ArrayList<Damageable> targets, GridCell[][] arr, GridPane1 grid) throws CloneNotSupportedException;

	public void setCurrentCooldown(int currentCoolDown) {
		if (currentCoolDown < 0)
			currentCoolDown = 0;
		else if (currentCoolDown > baseCooldown)
			currentCoolDown = baseCooldown;
		this.currentCooldown = currentCoolDown;
	}

	public String getName() {
		return name;
	}

	public int getManaCost() {
		return manaCost;
	}

	public int getBaseCooldown() {
		return baseCooldown;
	}
	
	public void FadeIn(Node n) {
		FadeTransition t = new FadeTransition();
		t.setDuration(Duration.millis(500));
		t.setNode(n);
		t.setFromValue(0);
		t.setToValue(1);
		t.setOnFinished(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				FadeOut(n);
			}
		});
		t.play();
	}
	
	public void FadeOut(Node n) {
		FadeTransition t = new FadeTransition();
		t.setDuration(Duration.millis(1000));
		t.setNode(n);
		t.setFromValue(1);
		t.setToValue(0);
		t.setOnFinished(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent arg0) {
				n.setVisible(false);
				n.setDisable(true);
			}
		});
		t.play();
	}

	public int getCastRange() {
		return castRange;
	}

	public AreaOfEffect getCastArea() {
		return castArea;
	}

	public int getRequiredActionPoints() {
		return requiredActionPoints;
	}
	
	public String getType() {
		return Type;
	}

}
