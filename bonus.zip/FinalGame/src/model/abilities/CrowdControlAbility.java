package model.abilities;

import java.util.ArrayList;

import controls.*;
import javafx.scene.layout.GridPane;
import model.effects.Effect;
import model.world.Champion;
import model.world.Damageable;

public class CrowdControlAbility extends Ability {
	private Effect effect;

	public CrowdControlAbility(String name, int cost, int baseCoolDown, int castRadius, AreaOfEffect area, int required,
			Effect effect) {
		super(name, cost, baseCoolDown, castRadius, area, required, "CC");
		this.effect = effect;

	}

	public Effect getEffect() {
		return effect;
	}

	@Override
	public void execute(ArrayList<Damageable> targets, GridCell[][] arr, GridPane1 grid) throws CloneNotSupportedException {
		for(Damageable d: targets)
		{
			Champion c =(Champion) d;
			c.getAppliedEffects().add((Effect) effect.clone());
			effect.apply(c);
			GridCell temp = new GridCell();
			switch(c.getName()) {
			case "Captain America": temp.setStyle("-fx-background-image: url('/tiles/CaptainAmericaBlue.png');");break;
			case "Deadpool": temp.setStyle("-fx-background-image: url('/tiles/DeadpoolBlue.png');");break;
			case "Dr Strange": temp.setStyle("-fx-background-image: url('/tiles/DrStrangeBlue.png');");break;
			case "Electro": temp.setStyle("-fx-background-image: url('/tiles/ElectroBlue.png');");break;
			case "Ghost Rider": temp.setStyle("-fx-background-image: url('/tiles/GhostRiderBlue.png');");break;
			case "Hela": temp.setStyle("-fx-background-image: url('/tiles/HelaBlue.png');");break;
			case "Hulk": temp.setStyle("-fx-background-image: url('/tiles/HulkBlue.png');");break;
			case "Iceman": temp.setStyle("-fx-background-image: url('/tiles/IcemanBlue.png');");break;
			case "Ironman": temp.setStyle("-fx-background-image: url('/tiles/IronmanBlue.png');");break;
			case "Loki": temp.setStyle("-fx-background-image: url('/tiles/LokiBlue.png');");break;
			case "Quicksilver": temp.setStyle("-fx-background-image: url('/tiles/QuicksilverBlue.png');");break;
			case "Spiderman": temp.setStyle("-fx-background-image: url('/tiles/SpidermanBlue.png');");break;
			case "Thor": temp.setStyle("-fx-background-image: url('/tiles/ThorBlue.png');");break;
			case "Venom": temp.setStyle("-fx-background-image: url('/tiles/VenomBlue.png');");break;
			case "Yellow Jacket": temp.setStyle("-fx-background-image: url('/tiles/YellowJacketBlue.png');");break;
			}
			GridPane.setRowIndex(temp, Math.abs(c.getLocation().x - 4));
			GridPane.setColumnIndex(temp, Math.abs(c.getLocation().y));
			grid.getChildren().add(temp);
			temp.setOpacity(0);
			FadeIn(temp);
		}
		
	}

}
