module FinalGame {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.media;
	requires java.desktop;
	requires javafx.base;
	opens engine;
	opens exceptions;
	opens model.abilities;
	opens model.effects;
	opens model.world;
	opens images;
	opens tiles;
	opens abilities;
	opens championInfo;
	opens controls;
}