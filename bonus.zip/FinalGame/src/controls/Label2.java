package controls;

import javafx.scene.control.Label;

public class Label2 extends Label{
	public Label2(double width, double height, double x, double y, String m) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
		this.setStyle("-fx-font-family: 'Aviano Black'; -fx-font-size: 20px; -fx-text-fill: WHITE;");
	}
}
