package controls;
import javafx.scene.layout.AnchorPane;

public class Transition extends AnchorPane {
	public Transition() {
		this.setPrefHeight(1080);
		this.setPrefWidth(1960);
		this.setStyle("-fx-background-color: #000000;");
		this.setLayoutX(0);
		this.setLayoutY(0);
	}
}
