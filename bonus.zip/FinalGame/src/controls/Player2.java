package controls;
import java.util.ArrayList;

import engine.Player;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.text.TextAlignment;
import model.world.*;

public class Player2 extends AnchorPane1{
	public ImageView1 Champion;
	ProgressBar1 Health;
	ProgressBar1 Mana;
	SpecialLabel PlayerName;
	Label1 ActionPoints;
	SpecialLabel HealthNo;
	SpecialLabel ManaNo;
	SpecialLabel ChampionName;
	SpecialLabel Type;
	ImageView1 c1;
	ImageView1 c2;
	ImageView1 c3;
	Champion C1;
	Champion C2;
	Champion C3;
	Player p;
	public ToggleButton1 a1;
	public ToggleButton1 a2;
	public ToggleButton1 a3;
	public ToggleButton1 a4;
	public Player2(Player p) {
		super(590, 181, 946, 0, "upright");
		this.p = p;
		Champion = new ImageView1(120, 120, 460, 10, "images/Spiderman.png");
		Champion.setPickOnBounds(true);
		Champion.setPreserveRatio(true);
		Health = new ProgressBar1(354, 23, 21, 52);
		Health.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
		Health.getStylesheets().add("/images/health.css");
		Mana = new ProgressBar1(354, 23, 21, 79);
		Mana.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);
		Mana.getStylesheets().add("/images/mana.css");
		PlayerName = new SpecialLabel(269, 17, 173, 17);
		ActionPoints = new Label1(275, 107);
		HealthNo = new SpecialLabel(100, 17, 268, 54);
		ManaNo = new SpecialLabel(92, 17, 276, 81);
		ChampionName = new SpecialLabel(190, 17, 368, 130);
		Type = new SpecialLabel(110, 17, 448, 146);
		c1 = new ImageView1(44, 49, 122, 0);
		c1.setPickOnBounds(true);
		c1.setPreserveRatio(true);
		c2 = new ImageView1(44, 49, 73, 0);
		c2.setPickOnBounds(true);
		c2.setPreserveRatio(true);
		c3 = new ImageView1(44, 49, 25, 0);
		c3.setPickOnBounds(true);
		c3.setPreserveRatio(true);
		C1 = p.getTeam().get(0);
		C2 = p.getTeam().get(1);
		C3 = p.getTeam().get(2);
		a4 = new ToggleButton1(75, 129);
		a3 = new ToggleButton1(146, 129);
		a2 = new ToggleButton1(217, 129);
		a1 = new ToggleButton1(287, 129);
		String r = "";
		switch(C1.getName()) {
		case "Captain America": r = "/images/CaptainAmerica.png";break;
		case "Deadpool": r = "/images/Deadpool.png";break;
		case "Dr Strange": r = "/images/DrStrange.png";break;
		case "Electro": r = "/images/Electro.png";break;
		case "Ghost Rider": r = "/images/GhostRider.png";break;
		case "Hela": r = "/images/Hela.png";break;
		case "Hulk": r = "/images/Hulk.png";break;
		case "Iceman": r = "/images/Iceman.png";break;
		case "Ironman": r = "/images/Ironman.png";break;
		case "Loki": r = "/images/Loki.png";break;
		case "Quicksilver": r = "/images/Quicksilver.png";break;
		case "Spiderman": r = "/images/Spiderman.png";break;
		case "Thor": r = "/images/Thor.png";break;
		case "Venom": r = "/images/Venom.png";break;
		case "Yellow Jacket": r = "/images/Yj.png";break;
		}
		c1.setImage(new Image(r));
		switch(C2.getName()) {
		case "Captain America": r = "/images/CaptainAmerica.png";break;
		case "Deadpool": r = "/images/Deadpool.png";break;
		case "Dr Strange": r = "/images/DrStrange.png";break;
		case "Electro": r = "/images/Electro.png";break;
		case "Ghost Rider": r = "/images/GhostRider.png";break;
		case "Hela": r = "/images/Hela.png";break;
		case "Hulk": r = "/images/Hulk.png";break;
		case "Iceman": r = "/images/Iceman.png";break;
		case "Ironman": r = "/images/Ironman.png";break;
		case "Loki": r = "/images/Loki.png";break;
		case "Quicksilver": r = "/images/Quicksilver.png";break;
		case "Spiderman": r = "/images/Spiderman.png";break;
		case "Thor": r = "/images/Thor.png";break;
		case "Venom": r = "/images/Venom.png";break;
		case "Yellow Jacket": r = "/images/Yj.png";break;
		}
		c2.setImage(new Image(r));
		switch(C3.getName()) {
		case "Captain America": r = "/images/CaptainAmerica.png";break;
		case "Deadpool": r = "/images/Deadpool.png";break;
		case "Dr Strange": r = "/images/DrStrange.png";break;
		case "Electro": r = "/images/Electro.png";break;
		case "Ghost Rider": r = "/images/GhostRider.png";break;
		case "Hela": r = "/images/Hela.png";break;
		case "Hulk": r = "/images/Hulk.png";break;
		case "Iceman": r = "/images/Iceman.png";break;
		case "Ironman": r = "/images/Ironman.png";break;
		case "Loki": r = "/images/Loki.png";break;
		case "Quicksilver": r = "/images/Quicksilver.png";break;
		case "Spiderman": r = "/images/Spiderman.png";break;
		case "Thor": r = "/images/Thor.png";break;
		case "Venom": r = "/images/Venom.png";break;
		case "Yellow Jacket": r = "/images/Yj.png";break;
		}
		c3.setImage(new Image(r));
		a4.setStyle("-fx-background-image: url(/abilities/LeaderAbility.png)");
		Label1 hp = new Label1(386, 55);
		Label1 mana = new Label1(386, 82);
		Label1 points = new Label1(310, 107);
		hp.setText("HP");
		mana.setText("MANA");
		points.setText("ACTION POINTS");
		this.getChildren().add(points);
		this.getChildren().add(mana);
		this.getChildren().add(hp);
		this.getChildren().add(ChampionName);
		this.getChildren().add(Health);
		this.getChildren().add(HealthNo);
		this.getChildren().add(PlayerName);
		this.getChildren().add(Type);
		this.getChildren().add(ActionPoints);
		this.getChildren().add(Champion);
		this.getChildren().add(Mana);
		this.getChildren().add(ManaNo);
		this.getChildren().add(c1);
		this.getChildren().add(c2);
		this.getChildren().add(c3);
		this.getChildren().add(a1);
		this.getChildren().add(a2);
		this.getChildren().add(a3);
		this.getChildren().add(a4);
	}
	
	public void Update(Champion c, Player p) {
		if(c instanceof Hero)
			Type.setText("HERO");
		else {
			if(c instanceof AntiHero)
				Type.setText("ANTI-HERO");
			else
				Type.setText("VILLAIN");
		}
		String r = "";
		switch(c.getName()) {
		case "Captain America": r = "/images/CaptainAmerica.png";a1.setStyle("-fx-background-image: url('/abilities/ShieldThrow.png')");a2.setStyle("-fx-background-image: url('/abilities/ICanDoThisAllDay.png')");a3.setStyle("-fx-background-image: url('/abilities/ShieldUp.png')");break;
		case "Deadpool": r = "/images/Deadpool.png";a1.setStyle("-fx-background-image: url('/abilities/TryHarder.png')");a2.setStyle("-fx-background-image: url('/abilities/8BulletsLeft.png')");a3.setStyle("-fx-background-image: url('/abilities/CantCatchMe.png')");break;
		case "Dr Strange": r = "/images/DrStrange.png";a1.setStyle("-fx-background-image: url('/abilities/TheEyeOfAgamotto.png')");a2.setStyle("-fx-background-image: url('/abilities/ThousandHand.png')");a3.setStyle("-fx-background-image: url('/abilities/MirrorDimension.png')");break;
		case "Electro": r = "/images/Electro.png";a1.setStyle("-fx-background-image: url('/abilities/FullyCharged.png')");a2.setStyle("-fx-background-image: url('/abilities/EMP.png')");a3.setStyle("-fx-background-image: url('/abilities/LightningStrike.png')");break;
		case "Ghost Rider": r = "/images/GhostRider.png";a1.setStyle("-fx-background-image: url('/abilities/DeathStare.png')");a2.setStyle("-fx-background-image: url('/abilities/FireBreath.png')");a3.setStyle("-fx-background-image: url('/abilities/ChainWhip.png')");break;
		case "Hela": r = "/images/Hela.png";a1.setStyle("-fx-background-image: url('/abilities/GodessOfDeath.png')");a2.setStyle("-fx-background-image: url('/abilities/ThornShield.png')");a3.setStyle("-fx-background-image: url('/abilities/ThornShower.png')");break;
		case "Hulk": r = "/images/Hulk.png";a1.setStyle("-fx-background-image: url('/abilities/Rage.png')");a2.setStyle("-fx-background-image: url('/abilities/HulkSmash.png')");a3.setStyle("-fx-background-image: url('/abilities/SunIsGettingRealLow.png')");break;
		case "Iceman": r = "/images/Iceman.png";a1.setStyle("-fx-background-image: url('/abilities/Frostbite.png')");a2.setStyle("-fx-background-image: url('/abilities/SubZero.png')");a3.setStyle("-fx-background-image: url('/abilities/HailStorm.png')");break;
		case "Ironman": r = "/images/Ironman.png";a1.setStyle("-fx-background-image: url('/abilities/IAmIronman.png')");a2.setStyle("-fx-background-image: url('/abilities/Unibeam.png')");a3.setStyle("-fx-background-image: url('/abilities/3000.png')");break;
		case "Loki": r = "/images/Loki.png";a1.setStyle("-fx-background-image: url('/abilities/GodOfMischief.png')");a2.setStyle("-fx-background-image: url('/abilities/TheHiddenDagger.png')");a3.setStyle("-fx-background-image: url('/abilities/FakeDeath.png')");break;
		case "Quicksilver": r = "/images/Quicksilver.png";a1.setStyle("-fx-background-image: url('/abilities/TimeInABottle.png')");a2.setStyle("-fx-background-image: url('/abilities/GoodAsNew.png')");a3.setStyle("-fx-background-image: url('/abilities/1Sec100Punch.png')");break;
		case "Spiderman": r = "/images/Spiderman.png";a1.setStyle("-fx-background-image: url('/abilities/GiveMeThat.png')");a2.setStyle("-fx-background-image: url('/abilities/WebTrap.png')");a3.setStyle("-fx-background-image: url('/abilities/Spiderverse.png')");break;
		case "Thor": r = "/images/Thor.png";a1.setStyle("-fx-background-image: url('/abilities/GodOfThunder.png')");a2.setStyle("-fx-background-image: url('/abilities/MjollnirThrow.png')");a3.setStyle("-fx-background-image: url('/abilities/BringMeThanos.png')");break;
		case "Venom": r = "/images/Venom.png";a1.setStyle("-fx-background-image: url('/abilities/HeadBite.png')");a2.setStyle("-fx-background-image: url('/abilities/WeAreVenom.png')");a3.setStyle("-fx-background-image: url('/abilities/Symbiosis.png')");break;
		case "Yellow Jacket": r = "/images/Yj.png";a1.setStyle("-fx-background-image: url('/abilities/LaserSting.png')");a2.setStyle("-fx-background-image: url('/abilities/QuANTaMANia.png')");a3.setStyle("-fx-background-image: url('/abilities/PymParticleUpsize.png')");break;
		}
		Champion.setImage(new Image(r));
		ManaNo.setText(c.getMana() + "/" + c.getMaxMana());
		HealthNo.setText(c.getCurrentHP() + "/" + c.getMaxHP());
		ActionPoints.setText(c.getCurrentActionPoints() + "/" + c.getMaxActionPointsPerTurn());
		Health.setProgress((float)c.getCurrentHP()/c.getMaxHP());
		Mana.setProgress((float)c.getMana()/c.getMaxMana());
		ChampionName.setText(c.getName().toUpperCase());
		PlayerName.setText(p.getName().toUpperCase());
		if(c.equals(p.getLeader()) && !a4.isDisable()) {
			a4.setVisible(true);
			a4.setText("Leader");
		}
		if(c.getAbilities().get(0).getCurrentCooldown() != 0)
			a1.setOpacity(0.5);
		if(c.getAbilities().get(1).getCurrentCooldown() != 0)
			a2.setOpacity(0.5);
		if(c.getAbilities().get(2).getCurrentCooldown() != 0)
			a3.setOpacity(0.5);
		if(c.getAbilities().get(0).getCurrentCooldown() == 0)
			a1.setOpacity(1);
		if(c.getAbilities().get(1).getCurrentCooldown() == 0)
			a2.setOpacity(1);
		if(c.getAbilities().get(2).getCurrentCooldown() == 0)
			a3.setOpacity(1);
		if(c.equals(p.getLeader()) && !a4.isDisable()) {
			a4.setVisible(true);
			a4.setText("Leader");
		}
		else
			a4.setVisible(false);
		setNotSelected();
	}
	
	public void updateDead() {
		ArrayList<String> dead = whoIsDead();
		String r = "";
		for(String s : dead) {
			switch(s) {
			case "Captain America": r = "/images/CaptainAmericaDead.png";break;
			case "Deadpool": r = "/images/DeadpoolDead.png";break;
			case "Dr Strange": r = "/images/DrStrangeDead.png";break;
			case "Electro": r = "/images/ElectroDead.png";break;
			case "Ghost Rider": r = "/images/GhostRiderDead.png";break;
			case "Hela": r = "/images/HelaDead.png";break;
			case "Hulk": r = "/images/HulkDead.png";break;
			case "Iceman": r = "/images/IcemanDead.png";break;
			case "Ironman": r = "/images/IronmanDead.png";break;
			case "Loki": r = "/images/LokiDead.png";break;
			case "Quicksilver": r = "/images/QuicksilverDead.png";break;
			case "Spiderman": r = "/images/SpidermanDead.png";break;
			case "Thor": r = "/images/ThorDead.png";break;
			case "Venom": r = "/images/VenomDead.png";break;
			case "Yellow Jacket": r = "/images/YjDead.png";break;
			}
			if(s.equals(C1.getName())) {
				c1.setImage(new Image(r));
				continue;
			}
			if(s.equals(C2.getName())) {
				c2.setImage(new Image(r));
				continue;
			}
			if(s.equals(C3.getName())) {
				c3.setImage(new Image(r));
				continue;
			}
		}
	}
	
	public void setNotSelected() {
		a1.setSelected(false);
		a2.setSelected(false);
		a3.setSelected(false);
		a4.setSelected(false);
	}
	public boolean isSelected() {
		if(a1.isSelected() || a2.isSelected() || a3.isSelected() || a4.isSelected())
			return true;
		return false;
	}
	
	public ArrayList<String> whoIsDead() {
		ArrayList<String> x = new ArrayList<String>();
		boolean flag = false;
		for(Champion c : p.getTeam())
			if(C1.getName().equals(c.getName()))
				flag = true;
		if(!flag)
			x.add(C1.getName());
		flag = false;
		for(Champion c : p.getTeam())
			if(C2.getName().equals(c.getName()))
				flag = true;
		if(!flag)
			x.add(C2.getName());
		flag = false;
		for(Champion c : p.getTeam())
			if(C3.getName().equals(c.getName()))
				flag = true;
		if(!flag)
			x.add(C3.getName());
		return x;
	}
}
