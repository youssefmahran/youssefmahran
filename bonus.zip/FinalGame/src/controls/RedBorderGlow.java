package controls;

import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

public class RedBorderGlow extends DropShadow{
	public RedBorderGlow() {
		super();
		setOffsetY(0f);
	    setOffsetX(0f);
    	setColor(Color.RED);
	    setWidth(45);
	    setHeight(45);
	}
}
