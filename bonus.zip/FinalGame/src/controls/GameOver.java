package controls;

public class GameOver extends AnchorPane1{
	public Button1 MainMenu;
	public Label3 Text;
	public GameOver() {
		super(750, 400, 393, 232, "centerr");
		MainMenu = new Button1(193, 279, 326, "MAIN MENU");
		MainMenu.getStylesheets().add("/images/application4.css");
		Text = new Label3(750, 122);
		this.getChildren().add(MainMenu);
		this.getChildren().add(Text);
		this.setStyle("-fx-background-color: BLACK;"
				+ "-fx-background-radius: 24px;"
				+ "-fx-border-width: 10px;"
				+ "-fx-border-color: White;"
				+ "-fx-border-radius: 20px;"
				);
	}
}
