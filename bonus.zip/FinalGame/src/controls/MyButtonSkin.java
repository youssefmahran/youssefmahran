package controls;


import javafx.animation.FadeTransition;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.skin.ToggleButtonSkin;

public class MyButtonSkin extends ToggleButtonSkin {

    public MyButtonSkin(ToggleButton btn) {
        super(btn);

        final FadeTransition fadeIn = new FadeTransition();
        fadeIn.setNode(btn);
        fadeIn.setToValue(1);
        btn.setOnMouseEntered(e -> fadeIn.playFromStart());

        final FadeTransition fadeOut = new FadeTransition();
        fadeOut.setNode(btn);
        fadeOut.setToValue(0.5);
        btn.setOnMouseExited(e -> fadeOut.playFromStart());

        btn.setOpacity(0.3);
    }
}