package controls;

import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

public class BlackBorderGlow extends DropShadow{
	public BlackBorderGlow() {
		super();
		setOffsetY(0f);
	    setOffsetX(0f);
    	setColor(Color.BLACK);
	    setWidth(45);
	    setHeight(45);
	}
}
