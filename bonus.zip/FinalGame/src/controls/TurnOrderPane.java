package controls;

import java.util.ArrayList;

import engine.PriorityQueue;
import javafx.scene.image.Image;
import model.world.Champion;

public class TurnOrderPane extends AnchorPane1{
	ImageView1 a;
	ImageView1 b;
	ImageView1 c;
	ImageView1 d;
	ImageView1 e;
	ImageView1 f;
	public TurnOrderPane() {
		super(1536, 176, 0, 687);
		a = new ImageView1(120, 120, 620, 30);
		a.setPickOnBounds(true);
		a.setPreserveRatio(true);
		b = new ImageView1(81, 111, 752, 44);
		b.setPickOnBounds(true);
		b.setPreserveRatio(true);
		c = new ImageView1(81, 111, 853, 44);
		c.setPickOnBounds(true);
		c.setPreserveRatio(true);
		d = new ImageView1(81, 111, 951, 44);
		d.setPickOnBounds(true);
		d.setPreserveRatio(true);
		e = new ImageView1(81, 111, 1041, 44);
		e.setPickOnBounds(true);
		e.setPreserveRatio(true);
		f = new ImageView1(81, 111, 1133, 44);
		f.setPickOnBounds(true);
		f.setPreserveRatio(true);
		Label1 g = new Label1(350, 80);
		g.setText("TURN ORDER:");
		g.setStyle("-fx-font-size: 28px;"
				+ "-fx-font-family: 'Aviano Black';"
				+ "-fx-text-fill: WHITE;");
		this.getChildren().add(e);
		this.getChildren().add(a);
		this.getChildren().add(b);
		this.getChildren().add(c);
		this.getChildren().add(d);
		this.getChildren().add(f);
		this.getChildren().add(g);
	}
	
	public void UpdateTurnOrder(PriorityQueue q) {
		Comparable[] arr = q.getElements();
		int i = 0;
		for(int j = q.size() - 1; j >= 0; j--) {
			String r = "";
			switch(((Champion) arr[j]).getName()) {
			case "Captain America": r = "/images/CaptainAmerica.png";break;
			case "Deadpool": r = "/images/Deadpool.png";break;
			case "Dr Strange": r = "/images/DrStrange.png";break;
			case "Electro": r = "/images/Electro.png";break;
			case "Ghost Rider": r = "/images/GhostRider.png";break;
			case "Hela": r = "/images/Hela.png";break;
			case "Hulk": r = "/images/Hulk.png";break;
			case "Iceman": r = "/images/Iceman.png";break;
			case "Ironman": r = "/images/Ironman.png";break;
			case "Loki": r = "/images/Loki.png";break;
			case "Quicksilver": r = "/images/Quicksilver.png";break;
			case "Spiderman": r = "/images/Spiderman.png";break;
			case "Thor": r = "/images/Thor.png";break;
			case "Venom": r = "/images/Venom.png";break;
			case "Yellow Jacket": r = "/images/Yj.png";break;
			}
			switch(i) {
			case 0: a.setVisible(true);a.setImage(new Image(r));break;
			case 1: b.setVisible(true);b.setImage(new Image(r));break;
			case 2: c.setVisible(true);c.setImage(new Image(r));break;
			case 3: d.setVisible(true);d.setImage(new Image(r));break;
			case 4: e.setVisible(true);e.setImage(new Image(r));break;
			case 5: f.setVisible(true);f.setImage(new Image(r));break;
			}
			i++;
		}
		while(i < 6) {
			switch(i) {
			case 0: a.setVisible(false);break;
			case 1: b.setVisible(false);break;
			case 2: c.setVisible(false);break;
			case 3: d.setVisible(false);break;
			case 4: e.setVisible(false);break;
			case 5: f.setVisible(false);break;
			}
			i++;
		}
	}
}
