package controls;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ToggleButton;
import model.world.Damageable;

public class GridCell extends ToggleButton{
	public ProgressBar health;
	public GridCell(){
		super();
		this.setPrefHeight(100);
		this.setPrefWidth(100);
		this.setAlignment(Pos.CENTER);
		health = new ProgressBar();
		health.setPrefSize(47, 6);
		health.setProgress(1);
		health.setLayoutY(0);
		health.setLayoutX(26.5);
		health.setStyle("-fx-accent: green;");
		health.setVisible(true);
		this.getChildren().add(health);
	}
}
