package controls;

import javafx.scene.control.ToggleButton;
import javafx.stage.Screen;

public class LeaderButton extends ToggleButton{
	public String name;
	public LeaderButton(int x, int y, String s) {
		super();
		name = s;
		String r = "";
		switch(s) {
		case "Captain America": r = "/images/CaptainAmerica.png";break;
		case "Deadpool": r = "/images/Deadpool.png";break;
		case "Dr Strange": r = "/images/DrStrange.png";break;
		case "Electro": r = "/images/Electro.png";break;
		case "Ghost Rider": r = "/images/GhostRider.png";break;
		case "Hela": r = "/images/Hela.png";break;
		case "Hulk": r = "/images/Hulk.png";break;
		case "Iceman": r = "/images/Iceman.png";break;
		case "Ironman": r = "/images/Ironman.png";break;
		case "Loki": r = "/images/Loki.png";break;
		case "Quicksilver": r = "/images/Quicksilver.png";break;
		case "Spiderman": r = "/images/Spiderman.png";break;
		case "Thor": r = "/images/Thor.png";break;
		case "Venom": r = "/images/Venom.png";break;
		case "Yellow Jacket": r = "/images/Yj.png";break;
		}
		ImageView1 view;
		if(s.equals("Spiderman"))
			view = new ImageView1(140, 140, true, r);
		else
			view = new ImageView1(120, 120, true, r);
		view.setStyle(""
                + "-fx-border-color: black;"
                + "-fx-border-style: solid;"
                + "-fx-border-width: 10;"
                + "-fx-border-radius: 10 10 10 10;"
        ); 
		this.setGraphic(view);
	    this.setStyle(
	                "-fx-background-radius: 50em; "
	                + "-fx-min-width: 60px; "
	                + "-fx-min-height: 60px; "
	                + "-fx-max-width: 130px; "
	                + "-fx-max-height: 60px;"
	        );
	    this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536)/2);
	    this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
	    this.setStyle("-fx-background-color: transparent;");
	}
}
