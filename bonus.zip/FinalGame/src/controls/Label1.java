package controls;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.text.TextAlignment;
import javafx.stage.Screen;

public class Label1 extends Label {
	public Label1(double width, double height, double x, double y, String m, String s) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		if(s.equals("center")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		}
		else {
			if(s.equals("right")) {
				this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
			}
			else {
				if(s.equals("left")) {
					this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
					this.setLayoutX(x);
				}
				else {
					if(s.equals("above")) {
						this.setLayoutX(x);
						this.setLayoutY(y);
					}
					else {
						if(s.equals("game")) {
							this.setTextAlignment(TextAlignment.CENTER);
							this.setAlignment(Pos.CENTER);
							this.setWrapText(true);
							this.setStyle("-fx-font-family: 'Aviano Black'; -fx-font-size: 20px; -fx-text-fill: WHITE;");
							this.setLayoutX(x);
							this.setLayoutY(y);
							this.setText(m);
							return;
						}
					}
				}
			}
		}
		this.setText(m);
		this.setAlignment(Pos.CENTER);
		this.setTextAlignment(TextAlignment.CENTER);
		this.setStyle("-fx-font-family: 'Aviano Black'; -fx-font-size: 28px; -fx-text-fill: WHITE;");
	}
	public Label1(double width, double height, double x, double y, String m) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
		this.setStyle("-fx-font-family: 'Aviano Black'; -fx-font-size: 28px; -fx-text-fill: WHITE;");
	}
	public Label1(double x, double y) {
		super();
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setStyle("-fx-font-family: 'Aviano Black';"
				+ "-fx-font-size: 15px;"
				+ "-fx-text-fill: WHITE;");
	}
	public Label1(double width, double height, double x, double y) {
		super();
		this.setPrefWidth(width);
		this.setPrefHeight(height);
		this.setAlignment(Pos.TOP_RIGHT);
		this.setTextAlignment(TextAlignment.RIGHT);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setStyle("-fx-font-family: 'Aviano Black';"
				+ "-fx-font-size: 15px;"
				+ "-fx-text-fill: BLACK;");
	}
	public Label1(double x, double y, String m) {
		super();
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
		this.setStyle("-fx-text-fill: WHITE;");
	}
}
