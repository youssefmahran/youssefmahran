package controls;

public class GamePane extends AnchorPane1{
	public GamePane() {
		super(1,1);
		
	}

}
