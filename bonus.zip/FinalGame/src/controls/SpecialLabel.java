package controls;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.text.TextAlignment;

public class SpecialLabel extends Label{
	public SpecialLabel(double width, double height, double x, double y) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setAlignment(Pos.CENTER_RIGHT);
		this.setTextAlignment(TextAlignment.RIGHT);
		this.setStyle("-fx-font-family: 'Aviano Black';"
				+ "-fx-font-size: 15px;"
				+ "-fx-text-fill: WHITE;");
	}
	public SpecialLabel(double width, double height, double x, double y, String s) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setAlignment(Pos.CENTER_LEFT);
		this.setTextAlignment(TextAlignment.LEFT);
		this.setStyle("-fx-font-family: 'Aviano Black';"
				+ "-fx-font-size: 15px;"
				+ "-fx-text-fill: WHITE;");
	}
}
