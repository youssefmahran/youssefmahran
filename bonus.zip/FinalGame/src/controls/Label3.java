package controls;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.text.TextAlignment;

public class Label3 extends Label{
	public Label3(double width, double height, double x, double y, String m) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
		this.setStyle("-fx-text-fill: WHITE;");
	}
	public Label3(double width, double y) {
		super();
		this.setPrefWidth(width);
		this.setLayoutX(0);
		this.setLayoutY(y);
		this.setTextAlignment(TextAlignment.CENTER);
		this.setAlignment(Pos.CENTER);
		this.setWrapText(true);
		this.setStyle("-fx-font-family: 'Aviano Black'; -fx-font-size: 30px; -fx-text-fill: WHITE;");	}
}
