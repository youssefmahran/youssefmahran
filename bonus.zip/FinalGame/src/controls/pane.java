package controls;

import javafx.scene.layout.Pane;

public class pane extends Pane{
	public pane() {
		super();
		this.setPrefSize(100, 100);
	}
}
