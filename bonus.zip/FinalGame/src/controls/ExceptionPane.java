package controls;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.TextAlignment;
import javafx.stage.Screen;

public class ExceptionPane extends AnchorPane{
	public ExceptionPane(String s) {
		super();
		this.setPrefHeight(256);
		this.setPrefWidth(676);
		this.setLayoutX((Screen.getPrimary().getBounds().getWidth() - 676)/2);
		this.setLayoutY(412 + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		this.setStyle("-fx-background-color: #000000;"
				+ "-fx-background-radius: 24px;"
				+ "-fx-border-width: 10px;"
				+ "-fx-border-color: WHITE;"
				+ "-fx-border-radius: 20px;"
				);
		Label1 x = new Label1(676, 181, 6, 5, s);
		x.setAlignment(Pos.CENTER);
		x.setTextAlignment(TextAlignment.CENTER);
		x.setWrapText(true);
		Button1 y = new Button1(109, 59, 558, 190, "OK");
		y.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				y.getParent().setVisible(false);
			}
		});
		y.getStylesheets().add("/images/application3.css");
		this.getChildren().add(y);
		this.getChildren().add(x);
	}
}
