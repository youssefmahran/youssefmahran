package controls;
import javafx.scene.control.ToggleButton;
import javafx.stage.Screen;

public class Hulk extends ToggleButton{
		public Hulk() {
			super();
			ImageView1 view = new ImageView1(120, 120, true, "/images/Hulk.png" );
			view.setStyle(""
	                + "-fx-border-color: black;"
	                + "-fx-border-style: solid;"
	                + "-fx-border-width: 10;"
	                + "-fx-border-radius: 10 10 10 10;"
	        ); 
			this.setGraphic(view);
		    this.setStyle(
		                "-fx-background-radius: 50em; "
		                + "-fx-min-width: 60px; "
		                + "-fx-min-height: 60px; "
		                + "-fx-max-width: 130px; "
		                + "-fx-max-height: 60px;"
		        );
		    this.setLayoutX(627.0 + (Screen.getPrimary().getBounds().getWidth() - 1600)/2);
		    this.setLayoutY(103.0 + (Screen.getPrimary().getBounds().getHeight() - 900)/2);
		    this.setStyle("-fx-background-color: transparent;");
		}
		public Hulk(int x, int y) {
			super();
			ImageView1 view = new ImageView1(120, 120, true, "/images/CaptainAmerica.png" );
			view.setStyle(""
	                + "-fx-border-color: black;"
	                + "-fx-border-style: solid;"
	                + "-fx-border-width: 10;"
	                + "-fx-border-radius: 10 10 10 10;"
	        ); 
			this.setGraphic(view);
		    this.setStyle(
		                "-fx-background-radius: 50em; "
		                + "-fx-min-width: 60px; "
		                + "-fx-min-height: 60px; "
		                + "-fx-max-width: 130px; "
		                + "-fx-max-height: 60px;"
		        );
		    this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536)/2);
		    this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
		    this.setStyle("-fx-background-color: transparent;");
		}
}