package controls;

import javafx.geometry.Pos;
import javafx.scene.text.TextAlignment;

public class ChampionInfo extends AnchorPane1{
	public Label2 info;
	public ChampionInfo() {
		super(450, 450, 600, 250, "c");
		this.setStyle(
                "-fx-background-radius: 50em; "
                + "-fx-min-width: 450px; "
                + "-fx-min-height: 450px; "
                + "-fx-max-width: 450px; "
                + "-fx-max-height: 450px;"
                + "-fx-background-color: BLACK"
        );
		info = new Label2(450, 450, 0, 0, "");
		info.setAlignment(Pos.CENTER);
		info.setTextAlignment(TextAlignment.CENTER);
		info.setWrapText(true);
		this.getChildren().add(info);
	}
}
