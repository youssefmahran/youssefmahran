package controls;

public class SettingsPane extends AnchorPane1{
	public CheckBox1 on;
	public CheckBox1 off;
	public Button1 Return;
	public Button1 MainMenu;
	public SettingsPane() {
		super(630, 306, 453, 251, "centerr");
		MainMenu = new Button1(193, 216, 157, "MAIN MENU");
		Return = new Button1(193, 216, 210, "RETURN");
		Label3 a = new Label3(149, 30, 164, 92, "TOGGLE MUSIC");
		on = new CheckBox1(23, 25, 323, 94);
		Label1 b = new Label1(353, 99, "ON");
		Label1 c = new Label1(415, 99, "OFF");
		off = new CheckBox1(23, 25, 390, 94);
		this.getChildren().add(c);
		this.getChildren().add(b);
		this.getChildren().add(a);
		this.getChildren().add(MainMenu);
		this.getChildren().add(Return);
		this.getChildren().add(off);
		this.getChildren().add(on);
		this.setStyle("-fx-background-color: BLACK;"
				+ "-fx-background-radius: 24px;"
				+ "-fx-border-width: 10px;"
				+ "-fx-border-color: White;"
				+ "-fx-border-radius: 20px;"
				);
		this.getStylesheets().add("/images/application4.css");
		a.getStylesheets().add("/images/application4.css");
		b.getStylesheets().add("/images/application4.css");
		c.getStylesheets().add("/images/application4.css");
		off.getStylesheets().add("/images/application4.css");
		on.getStylesheets().add("/images/application4.css");
		MainMenu.getStylesheets().add("/images/application4.css");
		Return.getStylesheets().add("/images/application4.css");
	}
}
