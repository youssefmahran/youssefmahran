package controls;

import javafx.scene.layout.AnchorPane;
import javafx.stage.Screen;

public class AnchorPane1 extends AnchorPane{

	public AnchorPane1(double width, double height, double x, double y, String s) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		if(s.equals("center")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		}
		else {
			if(s.equals("right")) {
				this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
			}
			else {
				if(s.equals("left")) {
					this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
					this.setLayoutX(x);
				}
				else {
					if(s.equals("c")) {
						this.setLayoutX((Screen.getPrimary().getBounds().getWidth() - width)/2);
						this.setLayoutY((Screen.getPrimary().getBounds().getHeight() - height)/2);
					}
					else{
						if(s.equals("upright")) {
							this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536));
							this.setLayoutY(y);
						}
						else {
							if(s.equals("upleft")) {
								this.setLayoutX(x);
								this.setLayoutY(y);
							}
							else {
								if(s.equals("centerr")) {
									this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536)/2);
									this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
								}
							}
						}
					}
				}
			}
		}
	}
	public AnchorPane1(double width, double height) {
		super();
		this.setPrefHeight(Screen.getPrimary().getBounds().getHeight());
		this.setPrefWidth(Screen.getPrimary().getBounds().getWidth());
	}
	public AnchorPane1(double width, double height, double x, double y) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536)/2);
		this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
	}
}
