package controls;

import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

public class BlueBorderGlow extends DropShadow{
	public BlueBorderGlow() {
		super();
		setOffsetY(0f);
	    setOffsetX(0f);
    	setColor(Color.BLUE);
	    setWidth(45);
	    setHeight(45);
	}
}
