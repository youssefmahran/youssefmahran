package controls;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.GridPane;
import javafx.stage.Screen;

public class GridPane1 extends GridPane{
	public GridCell aa;
	public GridCell ab;
	public GridCell ac;
	public GridCell ad;
	public GridCell ae;
	public GridCell ba;
	public GridCell bb;
	public GridCell bc;
	public GridCell bd;
	public GridCell be;
	public GridCell ca;
	public GridCell cb;
	public GridCell cc;
	public GridCell cd;
	public GridCell ce;
	public GridCell da;
	public GridCell db;
	public GridCell dc;
	public GridCell dd;
	public GridCell de;
	public GridCell ea;
	public GridCell eb;
	public GridCell ec;
	public GridCell ed;
	public GridCell ee;
	final public GridCell[][] Grid = new GridCell[5][5];
	final public HealthBar[][] health = new HealthBar[5][5];
	public GridPane1(double width, double height, double x, double y) {
		super();
		this.setPrefWidth(width);
		this.setPrefHeight(height);
		this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1536)/2);
		this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
		pane p00 = new pane();
		pane p01 = new pane();
		pane p02 = new pane();
		pane p03 = new pane();
		pane p04 = new pane();
		pane p10 = new pane();
		pane p11 = new pane();
		pane p12 = new pane();
		pane p13 = new pane();
		pane p14 = new pane();
		pane p20 = new pane();
		pane p21 = new pane();
		pane p22 = new pane();
		pane p23 = new pane();
		pane p24 = new pane();
		pane p30 = new pane();
		pane p31 = new pane();
		pane p32 = new pane();
		pane p33 = new pane();
		pane p34 = new pane();
		pane p40 = new pane();
		pane p41 = new pane();
		pane p42 = new pane();
		pane p43 = new pane();
		pane p44 = new pane();
		aa = new GridCell();
		ab = new GridCell();
		ac = new GridCell();
		ad = new GridCell();
		ae = new GridCell();
		ba = new GridCell();
		bb = new GridCell();
		bc = new GridCell();
		bd = new GridCell();
		be = new GridCell();
		ca = new GridCell();
		cb = new GridCell();
		cc = new GridCell();
		cd = new GridCell();
		ce = new GridCell();
		da = new GridCell();
		db = new GridCell();
		dc = new GridCell();
		dd = new GridCell();
		de = new GridCell();
		ea = new GridCell();
		eb = new GridCell();
		ec = new GridCell();
		ed = new GridCell();
		ee = new GridCell();
		Grid[0][0] = aa;
		Grid[0][1] = ab;
		Grid[0][2] = ac;
		Grid[0][3] = ad;
		Grid[0][4] = ae;
		Grid[1][0] = ba;
		Grid[1][1] = bb;
		Grid[1][2] = bc;
		Grid[1][3] = bd;
		Grid[1][4] = be;
		Grid[2][0] = ca;
		Grid[2][1] = cb;
		Grid[2][2] = cc;
		Grid[2][3] = cd;
		Grid[2][4] = ce;
		Grid[3][0] = da;
		Grid[3][1] = db;
		Grid[3][2] = dc;
		Grid[3][3] = dd;
		Grid[3][4] = de;
		Grid[4][0] = ea;
		Grid[4][1] = eb;
		Grid[4][2] = ec;
		Grid[4][3] = ed;
		Grid[4][4] = ee;
		aa.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				aa.setSelected(true);
			}
		});
		ab.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ab.setSelected(true);
			}
		});
		ac.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ac.setSelected(true);
			}
		});
		ad.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ad.setSelected(true);
			}
		});
		ae.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ae.setSelected(true);
			}
		});
		ba.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ba.setSelected(true);
			}
		});
		bb.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				bb.setSelected(true);
			}
		});
		bc.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				bc.setSelected(true);
			}
		});
		bd.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				bd.setSelected(true);
			}
		});
		be.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				be.setSelected(true);
			}
		});
		ca.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ca.setSelected(true);
			}
		});
		cb.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				cb.setSelected(true);
			}
		});
		cc.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				cc.setSelected(true);
			}
		});
		cd.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				cd.setSelected(true);
			}
		});
		ce.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ce.setSelected(true);
			}
		});
		da.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				da.setSelected(true);
			}
		});
		db.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				db.setSelected(true);
			}
		});
		dc.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				dc.setSelected(true);
			}
		});
		dd.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				dd.setSelected(true);
			}
		});
		de.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				de.setSelected(true);
			}
		});
		ea.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ea.setSelected(true);
			}
		});
		eb.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				eb.setSelected(true);
			}
		});
		ec.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ec.setSelected(true);
			}
		});
		ed.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ed.setSelected(true);
			}
		});
		ee.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				setNotSelected();
				ee.setSelected(true);
			}
		});
		HealthBar h00 = new HealthBar();
		HealthBar h01 = new HealthBar();
		HealthBar h02 = new HealthBar();
		HealthBar h03 = new HealthBar();
		HealthBar h04 = new HealthBar();
		HealthBar h10 = new HealthBar();
		HealthBar h11 = new HealthBar();
		HealthBar h12 = new HealthBar();
		HealthBar h13 = new HealthBar();
		HealthBar h14 = new HealthBar();
		HealthBar h20 = new HealthBar();
		HealthBar h21 = new HealthBar();
		HealthBar h22 = new HealthBar();
		HealthBar h23 = new HealthBar();
		HealthBar h24 = new HealthBar();
		HealthBar h30 = new HealthBar();
		HealthBar h31 = new HealthBar();
		HealthBar h32 = new HealthBar();
		HealthBar h33 = new HealthBar();
		HealthBar h34 = new HealthBar();
		HealthBar h40 = new HealthBar();
		HealthBar h41 = new HealthBar();
		HealthBar h42 = new HealthBar();
		HealthBar h43 = new HealthBar();
		HealthBar h44 = new HealthBar();
		health[0][0] = h00;
		health[0][1] = h01;
		health[0][2] = h02;
		health[0][3] = h03;
		health[0][4] = h04;
		health[1][0] = h10;
		health[1][1] = h11;
		health[1][2] = h12;
		health[1][3] = h13;
		health[1][4] = h14;
		health[2][0] = h20;
		health[2][1] = h21;
		health[2][2] = h22;
		health[2][3] = h23;
		health[2][4] = h24;
		health[3][0] = h30;
		health[3][1] = h31;
		health[3][2] = h32;
		health[3][3] = h33;
		health[3][4] = h34;
		health[4][0] = h40;
		health[4][1] = h41;
		health[4][2] = h42;
		health[4][3] = h43;
		health[4][4] = h44;
		p00.getChildren().add(aa);
		p01.getChildren().add(ab);
		p02.getChildren().add(ac);
		p03.getChildren().add(ad);
		p04.getChildren().add(ae);
		p10.getChildren().add(ba);
		p11.getChildren().add(bb);
		p12.getChildren().add(bc);
		p13.getChildren().add(bd);
		p14.getChildren().add(be);
		p20.getChildren().add(ca);
		p21.getChildren().add(cb);
		p22.getChildren().add(cc);
		p23.getChildren().add(cd);
		p24.getChildren().add(ce);
		p30.getChildren().add(da);
		p31.getChildren().add(db);
		p32.getChildren().add(dc);
		p33.getChildren().add(dd);
		p34.getChildren().add(de);
		p40.getChildren().add(ea);
		p41.getChildren().add(eb);
		p42.getChildren().add(ec);
		p43.getChildren().add(ed);
		p44.getChildren().add(ee);
		p00.getChildren().add(h00);
		p01.getChildren().add(h01);
		p02.getChildren().add(h02);
		p03.getChildren().add(h03);
		p04.getChildren().add(h04);
		p10.getChildren().add(h10);
		p11.getChildren().add(h11);
		p12.getChildren().add(h12);
		p13.getChildren().add(h13);
		p14.getChildren().add(h14);
		p20.getChildren().add(h20);
		p21.getChildren().add(h21);
		p22.getChildren().add(h22);
		p23.getChildren().add(h23);
		p24.getChildren().add(h24);
		p30.getChildren().add(h30);
		p31.getChildren().add(h31);
		p32.getChildren().add(h32);
		p33.getChildren().add(h33);
		p34.getChildren().add(h34);
		p40.getChildren().add(h40);
		p41.getChildren().add(h41);
		p42.getChildren().add(h42);
		p43.getChildren().add(h43);
		p44.getChildren().add(h44);
		GridPane.setRowIndex(p00, 4);
		GridPane.setColumnIndex(p00, 0);
		GridPane.setRowIndex(p01, 4);
		GridPane.setColumnIndex(p01, 1);
		GridPane.setRowIndex(p02, 4);
		GridPane.setColumnIndex(p02, 2);
		GridPane.setRowIndex(p03, 4);
		GridPane.setColumnIndex(p03, 3);
		GridPane.setRowIndex(p04, 4);
		GridPane.setColumnIndex(p04, 4);
		GridPane.setRowIndex(p10, 3);
		GridPane.setColumnIndex(p10, 0);
		GridPane.setRowIndex(p11, 3);
		GridPane.setColumnIndex(p11, 1);
		GridPane.setRowIndex(p12, 3);
		GridPane.setColumnIndex(p12, 2);
		GridPane.setRowIndex(p13, 3);
		GridPane.setColumnIndex(p13, 3);
		GridPane.setRowIndex(p14, 3);
		GridPane.setColumnIndex(p14, 4);
		GridPane.setRowIndex(p20, 2);
		GridPane.setColumnIndex(p20, 0);
		GridPane.setRowIndex(p21, 2);
		GridPane.setColumnIndex(p21, 1);
		GridPane.setRowIndex(p22, 2);
		GridPane.setColumnIndex(p22, 2);
		GridPane.setRowIndex(p23, 2);
		GridPane.setColumnIndex(p23, 3);
		GridPane.setRowIndex(p24, 2);
		GridPane.setColumnIndex(p24, 4);
		GridPane.setRowIndex(p30, 1);
		GridPane.setColumnIndex(p30, 0);
		GridPane.setRowIndex(p31, 1);
		GridPane.setColumnIndex(p31, 1);
		GridPane.setRowIndex(p32, 1);
		GridPane.setColumnIndex(p32, 2);
		GridPane.setRowIndex(p33, 1);
		GridPane.setColumnIndex(p33, 3);
		GridPane.setRowIndex(p34, 1);
		GridPane.setColumnIndex(p34, 4);
		GridPane.setRowIndex(p40, 0);
		GridPane.setColumnIndex(p40, 0);
		GridPane.setRowIndex(p41, 0);
		GridPane.setColumnIndex(p41, 1);
		GridPane.setRowIndex(p42, 0);
		GridPane.setColumnIndex(p42, 2);
		GridPane.setRowIndex(p43, 0);
		GridPane.setColumnIndex(p43, 3);
		GridPane.setRowIndex(p44, 0);
		GridPane.setColumnIndex(p44, 4);
		this.getChildren().add(p00);
		this.getChildren().add(p01);
		this.getChildren().add(p02);
		this.getChildren().add(p03);
		this.getChildren().add(p04);
		this.getChildren().add(p10);
		this.getChildren().add(p11);
		this.getChildren().add(p12);
		this.getChildren().add(p13);
		this.getChildren().add(p14);
		this.getChildren().add(p20);
		this.getChildren().add(p21);
		this.getChildren().add(p22);
		this.getChildren().add(p23);
		this.getChildren().add(p24);
		this.getChildren().add(p30);
		this.getChildren().add(p31);
		this.getChildren().add(p32);
		this.getChildren().add(p33);
		this.getChildren().add(p34);
		this.getChildren().add(p40);
		this.getChildren().add(p41);
		this.getChildren().add(p42);
		this.getChildren().add(p43);
		this.getChildren().add(p44);
	}

	public void setNotSelected() {
		for(int i = 0; i < 5; i++) {
			for(int j = 0; j < 5; j++) {
				Grid[i][j].setSelected(false);
			}
		}
	}
	public int getI(GridCell g) {
		for(int i = 0; i < 5; i++)
			for(int j = 0; j < 5; j++)
				if(g.equals(Grid[i][j]))
					return i;
		return -2;
	}
	public int getJ(GridCell g) {
		for(int i = 0; i < 5; i++)
			for(int j = 0; j < 5; j++)
				if(g.equals(Grid[i][j]))
					return j;
		return -2;
	}
}
