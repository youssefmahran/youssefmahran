package controls;

import javafx.scene.image.ImageView;
import javafx.stage.Screen;

public class ImageView2 extends ImageView{
	public ImageView2() {
		super();
		this.setFitHeight(450);
		this.setFitWidth(450);
		this.setLayoutX((Screen.getPrimary().getBounds().getWidth() - 450)/2);
		this.setLayoutY((Screen.getPrimary().getBounds().getHeight() - 450)/2);
	}
}
