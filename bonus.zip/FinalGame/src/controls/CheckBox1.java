package controls;

import javafx.scene.control.CheckBox;
import javafx.stage.Screen;

public class CheckBox1 extends CheckBox{

public CheckBox1(double width, double height, double x, double y, String s) {
	super();
	this.setPrefHeight(height);
	this.setPrefWidth(width);
	if(s.equals("center")) {
		this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
		this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
	}
	else {
		if(s.equals("right")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
		}
		else {
			if(s.equals("left")) {
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
				this.setLayoutX(x);
			}
		}
	}
	
	}

	public CheckBox1(double width, double height, double x, double y) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
	}
}
