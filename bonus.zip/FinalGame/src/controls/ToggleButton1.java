package controls;

import javafx.scene.control.ToggleButton;

public class ToggleButton1 extends ToggleButton{
	public ToggleButton1(double x, double y) {
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setPrefHeight(51);
		this.setPrefWidth(66);
	}
}
