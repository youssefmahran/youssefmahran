package controls;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Screen;

public class ImageView1 extends ImageView{
	public ImageView1(double width, double height, double x, double y, String m, String s) {
		super();
		this.setFitHeight(height);
		this.setFitWidth(width);
		if(s.equals("center")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		}
		else {
			if(s.equals("right")) {
				this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
			}
			else {
				if(s.equals("left")) {
					this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
					this.setLayoutX(x);
				}
			}
		}
		Image a = new Image(m);
		this.setImage(a);
	}
	
	public ImageView1(double width, double height, double x, double y, String m) {
		super();
		this.setFitHeight(height);
		this.setFitWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		Image a = new Image(m);
		this.setImage(a);
	}
	
	public ImageView1(double width, double height, double x, double y) {
		super();
		this.setFitHeight(height);
		this.setFitWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
	}
	
	public ImageView1(double width, double height, boolean x, String m) {
		super();
		this.setFitHeight(height);
		this.setFitWidth(width);
		this.setPreserveRatio(x);
		Image a = new Image(m);
		this.setImage(a);
	}
}
