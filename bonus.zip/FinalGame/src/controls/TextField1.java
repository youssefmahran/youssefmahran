package controls;

import javafx.scene.control.TextField;
import javafx.stage.Screen;

public class TextField1 extends TextField{
	public TextField1(double width, double height, double x, double y, String s) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		if(s.equals("center")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		}
		else {
			if(s.equals("right")) {
				this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
			}
			else {
				if(s.equals("left")) {
					this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
					this.setLayoutX(x);
				}
			}
		}
	}
	
	public TextField1(double width, double height, double x, double y) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
	}
}
