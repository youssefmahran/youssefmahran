package controls;

import javafx.scene.control.ProgressBar;

public class HealthBar extends ProgressBar{
	public HealthBar() {
		this.setPrefSize(57, 12);
		this.setLayoutX(20.5);
		this.setLayoutY(-1);
		this.setProgress(1);
		this.getStylesheets().add("/images/application5.css");
		this.setStyle("-fx-accent:green;");
	}

}
