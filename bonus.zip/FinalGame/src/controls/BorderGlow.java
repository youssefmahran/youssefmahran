package controls;

import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

public class BorderGlow extends DropShadow{
	public BorderGlow() {
		super();
		setOffsetY(0f);
	    setOffsetX(0f);
    	setColor(Color.WHITE);
	    setWidth(45);
	    setHeight(45);
	}
}
