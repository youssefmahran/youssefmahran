package controls;

import javafx.scene.control.ToggleButton;
import javafx.stage.Screen;

public class Next extends ToggleButton{
	public Next() {
		super();
		ImageView1 view16 = new ImageView1(120, 120, true, "/images/1st2.png");
		view16.setStyle(""
                + "-fx-border-color: black;"
                + "-fx-border-style: solid;"
                + "-fx-border-width: 10;"
                + "-fx-border-radius: 10 10 10 10;"
        );      
		ImageView1 view17 = new ImageView1(120, 120, true, "/images/2nd2.png");
		view17.setStyle(""
                + "-fx-border-color: black;"
                + "-fx-border-style: solid;"
                + "-fx-border-width: 10;"
                + "-fx-border-radius: 10 10 10 10;"
        );   
		this.setGraphic(view16);
	    this.setOnMouseEntered(e -> this.setGraphic(view17));
	    this.setOnMouseExited(e -> this.setGraphic(view16));
	    this.setStyle(
	                "-fx-background-radius: 70em; "
	                + "-fx-min-width: 60px; "
	                + "-fx-min-height: 60px; "
	                + "-fx-max-width: 130px; "
	                + "-fx-max-height: 60px;"
	        );
	    this.setLayoutX(740.0 + (Screen.getPrimary().getBounds().getWidth() - 1600)/2);
	    this.setLayoutY(684.0 + (Screen.getPrimary().getBounds().getHeight() - 900)/2);
	    this.setStyle("-fx-background-color: transparent;");
	}
}