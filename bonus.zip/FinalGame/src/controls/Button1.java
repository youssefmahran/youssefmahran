package controls;

import javafx.scene.control.Button;
import javafx.stage.Screen;

public class Button1 extends Button {
	public Button1(double width, double height, double x, double y, String m, String s) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		if(s.equals("center")) {
			this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960)/2);
			this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080)/2);
		}
		else {
			if(s.equals("right")) {
				this.setLayoutX(x + (Screen.getPrimary().getBounds().getWidth() - 1960));
				this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
			}
			else {
				if(s.equals("left")) {
					this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 1080));
					this.setLayoutX(x);
				}
			}
		}
		this.setText(m);
	}
	
	public Button1(double width, double height, double x, double y, String m) {
		super();
		this.setPrefHeight(height);
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
	}
	
	public Button1(double width, double x, double y, String m) {
		super();
		this.setPrefWidth(width);
		this.setLayoutX(x);
		this.setLayoutY(y);
		this.setText(m);
	}
	
	public Button1(double y, String m) {
		this.setLayoutX(1359 + (Screen.getPrimary().getBounds().getWidth() - 1536));
		this.setLayoutY(y + (Screen.getPrimary().getBounds().getHeight() - 864)/2);
		this.setPrefWidth(167);
		this.setPrefHeight(45);
		this.setText(m);
		this.getStylesheets().add("/images/application3.css");
	}
	
	

	public void setHover() {
		// TODO Auto-generated method stub
		
	}
}
